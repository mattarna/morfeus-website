---
name: design-system-builder
description: Build a complete, production-ready design system from scratch for any brand. Use this skill whenever the user wants to create a design system, define their brand visually, build a style guide, set up brand colors and fonts, create a visual identity system, or says things like "design system", "brand identity", "voglio creare il mio design system", "brand guidelines", "style guide", "identità visiva", "sistema di design", "come deve apparire il mio brand". Also trigger when the user wants to organize their existing brand assets into a structured system, or when they need a design system that an AI can use to generate on-brand assets. This skill produces a complete folder of files: markdown docs (AI-readable), CSS tokens (code-ready), HTML previews (human-viewable), and asset organization.
user-invocable: true
---

# Design System Builder

Build a complete design system from scratch — or from existing brand materials — that works for both humans and AI.

Respond in the user's language throughout. The skill is written in English but all user-facing conversation adapts to whatever language the user writes in.

## What this skill produces

A `design_system/` folder in the user's workspace containing:

| File | Purpose |
|---|---|
| `BRAND_GUIDELINES.md` | Canonical brand document — all 9 layers, every rule, every token |
| `README.md` | Operational index — what's in the folder, how to use it |
| `SKILL.md` | Agent manifest — lets any AI use this as a skill |
| `colors_and_type.css` | CSS custom properties + @font-face + base typography |
| `assets/fonts/README.md` | Font download instructions + naming convention |
| `assets/logo/README.md` | Logo variant map + usage contexts |
| `preview/_card.css` | Shared styles for preview cards |
| `preview/*.html` | 20+ visual preview cards (one per element) |
| `standalone.html` | Single-file browsable design system |

---

## The 4 phases

Move through them sequentially. Never skip a phase. Never generate files before Phase 2 is complete and approved by the user.

---

## PHASE 1: INTAKE

Goal: understand what the user already has.

Ask: **"Do you already have something I can start from? It can be brand materials (logo, colors, fonts, style guide), files, OR a link to your website or landing page."**

The user will fall into one of three branches:

### Branch A: User has a URL (website, landing page, or any live page)

This is the fastest path to a high-quality starting point. The AI visits the page and reverse-engineers the visual system.

**Step 1: Visit and capture the page.**

Use browser tools (Claude in Chrome, WebFetch, or equivalent) to:
- Navigate to the URL
- Take a full-page screenshot for visual reference
- Read the page HTML and CSS

If browser tools are not available, use WebFetch to get the page HTML/CSS source. If that also fails, ask the user for screenshots instead and switch to Branch B.

**Step 2: Extract the design tokens.**

From the page source, computed styles, and visual inspection, extract:

**Colors:**
- Background colors (inspect `body`, `main`, section containers — identify the foundation palette)
- Text colors (inspect `h1`, `h2`, `p`, `span` — identify the text hierarchy)
- Accent/action colors (inspect buttons, links, CTAs, highlights — identify primary and secondary accents)
- Border and subtle colors (inspect cards, dividers, inputs)
- Hover/active states if visible in the CSS (`:hover`, `:focus`, `:active` rules)

**Typography:**
- Font families (inspect `font-family` on headings and body — identify display vs. body fonts)
- Font weights used (inspect `font-weight` across elements)
- Font sizes for each hierarchy level (H1, H2, H3, body, captions)
- Line heights and letter-spacing
- Any italic or accent font usage

**Spacing & Layout:**
- Section padding (vertical rhythm)
- Content max-width
- Card padding and gaps
- Side padding / margins

**Components:**
- Button styles (background, radius, padding, shadow, font)
- Card styles (background, border, radius, shadow)
- Input styles if present (background, border, radius)
- Badge/tag styles if present

**Gradients & Effects:**
- Background gradients
- Box shadows
- Backdrop filters
- Any glow or atmospheric effects

**Assets:**
- Logo (download if visible — check `<img>` tags, background-images, SVGs)
- Favicon
- Any recurring icons or visual elements

**Step 3: Present findings.**

Organize everything into a structured report:

```
EXTRACTED FROM: [URL]

COLORS:
  Backgrounds: [hex codes with role]
  Primary accent: [hex] (found on: buttons, links, etc.)
  Secondary accent: [hex] (found on: labels, tags, etc.)
  Text: [primary hex], [secondary hex], [tertiary hex]

TYPOGRAPHY:
  Display: [font-family] at weights [list]
  Body: [font-family] at weights [list]
  Accent: [font-family or none]
  Scale: H1 [size], H2 [size], H3 [size], body [size]

SPACING:
  Section padding: ~[value]
  Content max-width: ~[value]
  Card gap: ~[value]

COMPONENTS:
  Buttons: [description of style]
  Cards: [description of style]
  Inputs: [description if present]

GRADIENTS/EFFECTS: [list what was found]
LOGO: [downloaded / not found]
```

Ask: **"Here's what I extracted from your page. Is this accurate? Anything to correct, add, or change direction on?"**

After confirmation, proceed to Phase 2 with this as the foundation. Skip assessment questions already answered by the extraction.

### Branch B: User has files (not a URL)

Ask them to place their materials in the workspace folder. Explain what's useful: logo files, color palette, font files or names, brand guidelines, screenshots of pages or assets they like.

Once files are available, READ everything. Extract:
- Colors (primary, secondary, accent, backgrounds, text)
- Fonts (display, body, accent)
- Logo variants (which backgrounds they work on)
- Tone/style patterns (dark/light, minimal/bold, etc.)
- Existing rules

Summarize findings back to the user for confirmation. Then proceed to Phase 2 — skip questions you already have answers to.

### Branch C: Starting from scratch

Say: "No problem — I'll guide you through every decision. Let's start." Proceed to Phase 2.

---

## PHASE 2: ASSESSMENT

Goal: gather every decision needed to build the 9 layers. This is a conversation, not a form. Ask 2-3 questions at a time. Build on answers.

Read `references/assessment.md` for the complete question bank organized by layer.

### Block 1: Identity & Business

Ask about:
- What the business does and who it serves
- The brand feeling in one sentence (offer examples: "Premium and authoritative", "Friendly and approachable", "Technical and precise", "Bold and energetic")
- What the brand is NOT (equally important — offer examples: "Not corporate", "Not hype", "Not cheap")
- Every surface the design system must serve (landing pages, email, slides, social, PDF, etc.)

### Block 2: Visual Direction

Ask about:
- Dark brand or light brand? Explain the implications of each
- Specific colors in mind, or should you propose a palette from the identity?
- Font preferences, or should you recommend based on tone?
- Any surfaces needing inverted/light mode? (email, PDF, print)

If proposing colors/fonts, read `references/blueprint.md` for guidance on selection. Present 2-3 palette options with rationale. Let the user choose.

### Block 3: Content & Tone

Ask about:
- Primary language of the audience
- Formal or informal register (tu/lei, you/Your, etc.)
- Banned words/phrases and loved words/phrases

### Block 4: Confirmation

Present the complete brief as a structured summary:

```
BRAND: [name]
IDENTITY: [one-sentence feel]
ATTRIBUTES: [3-5 what it IS]
ANTI-ATTRIBUTES: [3-5 what it's NOT]
SURFACES: [list with role of each]

PALETTE:
  Foundation: [dark/light] — [2-3 background hex codes]
  Primary accent: [hex] + hover [hex] + pressed [hex]
  Secondary accent: [hex]
  Text: [3 hex codes for primary/secondary/tertiary]
  Light mode needed: [yes/no] — for which surfaces

TYPOGRAPHY:
  Display: [font name] — [weight] — [where to get it]
  Body: [font name] — [weight range]
  Accent: [font name or "none"]

CONTENT:
  Language: [primary language]
  Register: [formal/informal]
  Tone: [3-4 words]
  Banned: [list]
```

**Wait for explicit approval.** Do not proceed to Phase 3 until the user confirms.

---

## PHASE 3: GENERATION

Goal: create every file. Follow this exact sequence — each step builds on the previous.

Read `references/blueprint.md` for the complete specification of what each layer must contain. That document defines the 9 layers, all component states, file structure, naming conventions, and quality standards. It is the source of truth for generation.

### Step 1: `colors_and_type.css`

The foundation file. Contains:

**@font-face declarations** — paths relative to CSS file location (`assets/fonts/[name].ttf`). Include `font-display: swap`. Define fallback stacks.

**CSS custom properties** — organize in this exact order:
1. Foundation colors (backgrounds)
2. Primary accent (rest, hover, pressed)
3. Secondary accent
4. Text colors (3 levels)
5. Utility colors (hairline, card-bg, input-bg — as rgba)
6. Glow / shadow system (as complete box-shadow values)
7. Gradients (signature, atmosphere, border, section)
8. Radii scale (sm through pill)
9. Spacing scale (space-1 through space-30)
10. Layout constraints (content-max, prose-max, content-pad)
11. Motion timing (easing curves + duration tokens)
12. Font stack variables (font-display, font-italic, font-body)

**Base styles** — html/body background + text + font, body::before for atmosphere gradient, ::selection.

**Semantic typography** — h1/.h1 through h3/.h3, .italic-accent, p/.body, .body-card, .label/.tag-label, .caption/.micro, code, a/a:hover.

If light mode is needed, add a `[data-theme="light"]` block overriding all tokens that change.

### Step 2: `preview/_card.css`

Shared stylesheet for preview cards. Must:
- Import `../colors_and_type.css`
- Define `.card` container (700px wide, padded, brand background)
- Define `.row`, `.col`, `.swatch`, `.mini-label`, `.meta` helpers
- Kill the atmosphere gradient in cards (`body::before { display: none; }`)

### Step 3: `preview/*.html` — one per element

Read `references/preview-templates.md` for HTML patterns. Generate minimum 20 files:

**Color group:** `colors-foundation.html`, `colors-accents.html`, `colors-text.html`, `colors-dominance.html`
**Type group:** `type-display.html`, `type-accent.html`, `type-body.html`, `type-scale.html`
**Structure group:** `spacing.html`, `breakpoints.html`, `radii.html`, `shadows-and-glow.html`
**Component group:** `buttons.html`, `cards.html`, `form-input.html`, `badges-and-tags.html`, `check-icon.html`
**Atmosphere group:** `gradient-signature.html`, `atmosphere.html`, `logos.html`, `motion.html`

If light mode exists, add `colors-light-mode.html`.

Each preview file must:
- Be self-contained (link to `_card.css`)
- Show actual rendered elements with real token values
- Include hex codes, token names, and usage notes as visible text
- For interactive elements: include working hover/focus/active states via CSS `:hover`, `:focus`, `:active`

**Component states — non-negotiable:**
- `buttons.html`: rest, hover, focus, active, disabled, loading (all visible)
- `form-input.html`: rest, focus, error, success, disabled (all visible)
- `cards.html`: rest + hover (interactive)

### Step 4: `assets/fonts/README.md`

Exact font names, weights, download URLs, file naming expected by the CSS, and step-by-step instructions a non-technical person can follow. If user provided fonts in Phase 1, note they're already in place.

### Step 5: `assets/logo/README.md`

If user provided logos: organize into `[brand]-w.png` (white), `[brand]-b.png` (black), `[brand]-c.png` (color) naming. Document each file and usage.

If no logos: explain the naming convention and what files to add later.

### Step 6: `BRAND_GUIDELINES.md`

The canonical document. All 9 layers. Structure per `references/blueprint.md`:
1. Identity (statement, attributes, anti-attributes, surfaces)
2. Color System (all tokens, dominance rules, accessibility, light mode if applicable)
3. Typography (stack, hierarchy table, responsive scale, accent rules)
4. Spacing & Layout (breakpoints, scale, constraints, responsive spacing)
5. Components (every component with ALL states in CSS)
6. Motion & Animation (timing tokens, animation map, forbidden list)
7. Gradients & Atmosphere (each gradient with CSS + usage rules)
8. Iconography & Assets (icon approach, logo variants, image treatment, emoji rules)
9. Content Rules (language, casing, punctuation, banned words, good/bad examples)

Every value is explicit. Every rule has do/don't framing. CSS blocks are copy-paste ready.

### Step 7: `SKILL.md` (the agent manifest)

Under 2KB. Frontmatter with name + description. Body tells any AI:
- Read README.md first
- BRAND_GUIDELINES.md is the source of truth
- colors_and_type.css is the drop-in stylesheet
- The 5 most critical constraints for this specific brand

### Step 8: `README.md`

Operational index:
- What this design system is (2-3 sentences)
- Identity in one line
- What the brand is / is not
- Complete folder map with one-line per file
- Visual foundations summary (scannable)
- Content rules summary
- Links to all docs

### Step 9: `standalone.html`

Single HTML file that displays all preview cards. Include:
- Navigation sidebar or table of contents with sections
- Each section embeds the corresponding preview HTML content (inline, not iframe)
- Uses the CSS tokens for consistent rendering
- Works offline, no external dependencies

---

## PHASE 4: REVIEW

After generating all files:

1. **List what was created** with file paths and one-line descriptions
2. **Direct user to `standalone.html`** — "Open this file in your browser to see your complete design system."
3. **Ask for feedback** — "What would you like to adjust? Colors, fonts, spacing, components — anything."
4. **Iterate** — update CSS tokens first (previews auto-reflect changes), then update any files needing structural changes
5. **Finalize** — "Your design system is ready. Any AI that reads the SKILL.md in this folder will generate on-brand assets for you."

---

## Quality gates (verify before delivering)

- [ ] All 9 layers documented in BRAND_GUIDELINES.md
- [ ] Every color has token name + hex + defined role
- [ ] Every component has ALL applicable states
- [ ] Light mode tokens exist if any surface needs them
- [ ] Breakpoints defined with explicit pixel values
- [ ] Body text minimum 16px desktop, 15px mobile
- [ ] WCAG AA contrast verified (4.5:1 body, 3:1 headings)
- [ ] Focus states on all interactive elements
- [ ] Preview HTML files render correctly (test by reading back the generated HTML)
- [ ] No vague descriptions — every value is a number
- [ ] No CDN dependencies — everything resolves from relative paths
- [ ] Font download instructions are clear and complete
