# Assessment Question Bank

Complete question set for Phase 2. Organized by layer. Ask 2-3 at a time, conversationally. Adapt wording to user's language.

**If coming from Branch A (URL extraction):** Many visual questions (colors, fonts, spacing, components) are already answered. Focus the assessment on identity, tone, content rules, and confirming/adjusting what was extracted. Frame questions as "I extracted X from your page — do you want to keep this or change direction?"

**If coming from Branch B (files):** Skip questions answered by the materials. Focus on gaps.

**If coming from Branch C (scratch):** Ask everything.

---

## Layer 1: Identity & Business

### Core identity
1. **What does your business do?** In one sentence — what you sell or offer, and to whom.
2. **Who is your ideal customer?** Age range, profession, skill level, what they care about.
3. **What problem do you solve?** The specific pain point your product/service addresses.

### Brand personality
4. **If your brand were a person, how would they dress and talk?** (This reveals tone better than abstract adjectives.)
5. **Pick the one sentence that best describes how your brand should feel:**
   - "Premium and authoritative — I know what I'm doing and you can trust me"
   - "Friendly and approachable — I'm like a smart friend who helps you"
   - "Technical and precise — I respect your intelligence and give you the real stuff"
   - "Bold and energetic — I move fast and I want you to move with me"
   - "Calm and minimal — less noise, more signal"
   - Or: describe it in your own words
6. **What 3-5 words IS your brand?** (Dark, premium, clean, warm, technical, playful, bold, quiet, sharp, elegant, raw, accessible...)
7. **What 3-5 words is your brand NOT?** Just as important. (Not corporate, not cheap, not hype, not generic, not cold, not playful, not loud...)

### Surfaces
8. **What surfaces does this design system need to serve?** Check all that apply:
   - Landing page (opt-in / lead capture)
   - Sales page (long-form conversion)
   - Thank-you / confirmation page
   - Email (newsletter, sequences, transactional)
   - Webinar / presentation slides (what aspect ratio? 16:9?)
   - Social media graphics (which platforms? What formats?)
   - PDF / downloadable documents
   - Blog / content pages
   - App / dashboard UI
   - Other: ___
9. **For each surface:** What is its primary goal? (Example: "Landing page — collect the email. One goal, nothing else.")

---

## Layer 2: Color System

### Palette direction
10. **Dark brand or light brand?**
    - Dark = near-black backgrounds, light text. Feels premium, dramatic, modern. Works well for tech, luxury, creative.
    - Light = near-white backgrounds, dark text. Feels clean, open, trustworthy. Works well for SaaS, education, health.
    - Mixed = different surfaces use different modes (e.g., website dark, email light)
11. **Do you have specific colors in mind?** If yes, share hex codes or screenshots. If not, I'll propose options based on your identity.
12. **What emotion should your primary accent color convey?**
    - Energy / urgency / action → warm (orange, red, yellow)
    - Trust / calm / depth → cool (blue, teal, green)
    - Creativity / premium / uniqueness → rich (purple, magenta, deep teal)
    - Neutrality / sophistication → muted (desaturated versions of any)
13. **Do any surfaces need an inverted color scheme?** Email is typically light-background even for dark brands. PDF might need print-friendly colors.

### Specifics (if user wants to go deeper)
14. **How much accent color is too much?** Some brands want accents on every element. Others want 95% neutral with rare pops of color. Where are you?
15. **Do you have a secondary accent?** A second color used for structure/organization (not competing with the primary for attention).

---

## Layer 3: Typography

### Font preferences
16. **Do you have fonts you already use or love?** Share names or links.
17. **If starting fresh, what personality should the headline font have?**
    - Geometric sans (modern, clean, confident) — e.g., Clash Display, General Sans, Cabinet Grotesk
    - Humanist sans (warm, approachable, readable) — e.g., DM Sans, Plus Jakarta Sans, Nunito
    - Serif (authoritative, editorial, classic) — e.g., Playfair Display, DM Serif, Fraunces
    - Slab serif (bold, grounded, industrial) — e.g., Roboto Slab, Zilla Slab
    - Mono (technical, developer-oriented) — e.g., JetBrains Mono, Space Mono
18. **Do you want a typographic accent?** An italic or serif word inside sans-serif headings for contrast. (Show example: "Come usare Claude *al massimo* nel tuo lavoro" where "al massimo" is in a contrasting italic serif.) Not every brand needs this.
19. **Body font preference:** Typically a clean sans-serif. Any preference, or should I match it to the display font?

---

## Layer 4: Spacing & Layout

20. **Content density preference:**
    - Breathing / spacious (lots of whitespace, generous section padding) — feels premium, calm
    - Standard (balanced padding, comfortable reading) — feels professional
    - Dense / compact (tighter spacing, more content per screen) — feels data-rich, technical
21. **Maximum content width?** Standard is ~1120px. Wider (1280px+) for data-heavy layouts. Narrower (~960px) for content-focused.
22. **Do you need a fixed header/navigation?** Some brands want a sticky header. Others prefer clean full-page sections.

---

## Layer 5: Components

23. **Button style preference:**
    - Solid with glow/shadow (punchy, draws attention)
    - Solid flat (clean, modern, no shadow)
    - Outline/ghost as primary (minimal, sophisticated)
24. **Card style preference:**
    - Subtle at rest, alive on hover (dormant → alive metaphor)
    - Visible at rest with clear boundaries
    - Borderless with shadow only
25. **Do you need form inputs?** (For landing pages with opt-in forms, application pages, etc.)

---

## Layer 6: Motion

26. **Motion personality:**
    - Minimal (almost no animation — color changes only) — serious, fast
    - Subtle (small lifts, color transitions, focus feedback) — professional, polished
    - Expressive (larger movements, entrance animations) — playful, dynamic
    - *Note: most professional brands land on "subtle." Recommend this unless the user has strong reasons for the others.*

---

## Layer 7: Gradients & Atmosphere

27. **Do you want atmospheric depth?** A subtle gradient overlay that creates visual richness without being consciously visible. (Recommended for dark brands. Less common for light brands.)
28. **Signature gradient?** A gradient that combines your two accent colors as a brand fingerprint. Used sparingly on hero text or decorative elements.

---

## Layer 8: Iconography & Assets

29. **Do you have a custom icon set?** Most brands don't need one. If not, the system will default to a recommended icon library (Lucide, Phosphor, or Heroicons) matched to your typography.
30. **Logo variants:** Do you have your logo in multiple formats? (white version for dark backgrounds, dark version for light, color version for special use.) If not, which variants do you need?
31. **Image treatment:** How should photos and screenshots look in your brand?
    - Rounded corners with subtle border (polished, premium)
    - Sharp corners, no border (clean, editorial)
    - Rounded with glow/shadow (dramatic, dark brands)
32. **Emoji policy:**
    - Never (professional, serious)
    - Only in body text where it clarifies (balanced — recommended)
    - Freely used (casual, playful)

---

## Layer 9: Content Rules

33. **Primary language?** (The language your audience reads)
34. **Register:** Formal (lei/vous/usted) or informal (tu/du/tú)?
35. **Words or phrases that are BANNED?** Things that don't fit your tone. Examples of common bans: "game-changer", "revolutionary", "unlock", "empower", emoji stacks, exclamation stacking.
36. **Words or phrases you LOVE?** Words that feel right for your brand.
37. **Casing preference for headlines:** Sentence case (recommended), Title Case, or ALL CAPS for labels?

---

## Summary template

After collecting all answers, compile into this format for user approval:

```
BRAND: [name]
IDENTITY: [one-sentence feel]
ATTRIBUTES: [what it IS]
ANTI-ATTRIBUTES: [what it's NOT]
SURFACES: [list with roles]

PALETTE:
  Mode: [dark / light / mixed]
  Foundation: [2-3 hex codes]
  Primary accent: [hex] → hover [hex] → pressed [hex]
  Secondary accent: [hex] (if applicable)
  Text: primary [hex], secondary [hex], tertiary [hex]
  Light mode: [yes/no — for which surfaces]

TYPOGRAPHY:
  Display: [name, weight, source]
  Body: [name, weight range, source]
  Accent: [name or "none"]

SPACING:
  Density: [breathing / standard / dense]
  Content max: [px]

COMPONENTS:
  Buttons: [solid+glow / solid flat / outline]
  Cards: [subtle→alive / visible / borderless]
  Forms: [yes/no]

MOTION: [minimal / subtle / expressive]
ATMOSPHERE: [yes/no]
SIGNATURE GRADIENT: [yes/no]

CONTENT:
  Language: [primary]
  Register: [formal/informal]
  Tone: [3-4 words]
  Banned: [list]
  Loved: [list]
  Casing: [sentence / title / uppercase labels]
```
