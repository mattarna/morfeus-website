# Preview HTML Templates

Patterns for generating the `preview/*.html` files. Each file is a visual card showing one design system element rendered in-browser.

## Shared structure

Every preview file follows this pattern:

```html
<!doctype html>
<html><head>
  <meta charset="utf-8">
  <title>[Element name]</title>
  <link rel="stylesheet" href="_card.css">
  <style>
    /* Element-specific styles here */
  </style>
</head>
<body>
  <div class="card">
    <!-- Rendered element(s) with visible annotations -->
  </div>
</body></html>
```

Key rules:
- Every file links to `_card.css` (which imports the main CSS tokens)
- The `.card` container is 700px wide — design within this
- Show the ACTUAL rendered element, not a description of it
- Annotate with token names and hex values as visible text using `.mini-label` and `.meta` classes
- For interactive elements, use real CSS `:hover`, `:focus`, `:active` — the user will interact with these in-browser

## _card.css template

```css
/* Shared card styles — every preview/*.html uses this */
@import url("../colors_and_type.css");

html, body {
  margin: 0;
  background: var(--night); /* or var(--snow) for light brands */
  color: var(--ghost); /* or var(--body) for light brands */
  font-family: var(--font-body);
}
body::before { display: none; } /* kill atmosphere in preview cards */

.card {
  box-sizing: border-box;
  width: 700px;
  min-height: 150px;
  padding: 28px;
  background: var(--night); /* match brand foundation */
  position: relative;
  overflow: hidden;
}

.row { display: flex; align-items: center; gap: 20px; flex-wrap: wrap; }
.col { display: flex; flex-direction: column; gap: 12px; }

.swatch {
  width: 100%;
  border-radius: 10px;
  border: 1px solid rgba(255,255,255,0.08);
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
  padding: 12px;
  box-sizing: border-box;
}
.swatch .name {
  font-size: 12px;
  font-weight: 700;
  letter-spacing: 0.08em;
  text-transform: uppercase;
}
.swatch .hex {
  font-family: ui-monospace, Menlo, monospace;
  font-size: 11px;
  opacity: 0.75;
}

.mini-label {
  font-family: var(--font-body);
  font-weight: 700;
  font-size: 11px;
  letter-spacing: 0.18em;
  text-transform: uppercase;
  color: var(--muted);
}

.meta {
  font-family: ui-monospace, Menlo, monospace;
  font-size: 11px;
  color: var(--muted);
}
```

Adapt colors for light brands: swap `--night` for `--snow`, `rgba(255,255,255,...)` borders for `rgba(0,0,0,...)`, etc.

---

## Template: Color swatches

```html
<!-- colors-foundation.html -->
<div class="card">
  <div class="row" style="display:grid; grid-template-columns:repeat(3,1fr); gap:16px;">
    <div class="swatch" style="height:124px; background:#0B0B0C; border-color:rgba(255,255,255,0.10);">
      <span class="name" style="color:#fff;">Night</span>
      <span class="hex" style="color:rgba(255,255,255,0.55);">#0B0B0C · primary bg</span>
    </div>
    <div class="swatch" style="height:124px; background:#0F0E1A;">
      <span class="name" style="color:#fff;">Deep Space</span>
      <span class="hex" style="color:rgba(255,255,255,0.55);">#0F0E1A · alt sections</span>
    </div>
    <!-- repeat for each foundation color -->
  </div>
</div>
```

Pattern: grid of swatches, each with the actual color as background, name and hex visible on top.

---

## Template: Accent colors with states

```html
<!-- colors-accents.html -->
<div class="card">
  <div class="mini-label" style="margin-bottom:16px;">Primary Accent</div>
  <div class="row" style="gap:12px;">
    <div style="text-align:center;">
      <div style="width:80px;height:80px;border-radius:10px;background:var(--accent);"></div>
      <div class="meta" style="margin-top:8px;">Rest<br>#HEXVAL</div>
    </div>
    <div style="text-align:center;">
      <div style="width:80px;height:80px;border-radius:10px;background:var(--accent-hover);"></div>
      <div class="meta" style="margin-top:8px;">Hover<br>#HEXVAL</div>
    </div>
    <div style="text-align:center;">
      <div style="width:80px;height:80px;border-radius:10px;background:var(--accent-pressed);"></div>
      <div class="meta" style="margin-top:8px;">Pressed<br>#HEXVAL</div>
    </div>
  </div>
  <!-- Repeat for secondary accent -->
</div>
```

---

## Template: Typography

```html
<!-- type-display.html -->
<div class="card">
  <div class="mini-label" style="margin-bottom:20px;">Display — [Font Name]</div>
  <div class="col" style="gap:24px;">
    <div>
      <div class="meta">H1 · clamp(40px, 6vw, 68px) · weight 600 · -0.025em</div>
      <h1 style="margin:8px 0 0;">The quick brown fox</h1>
    </div>
    <div>
      <div class="meta">H2 · clamp(32px, 4.5vw, 48px) · weight 600 · -0.02em</div>
      <h2 style="margin:8px 0 0;">The quick brown fox</h2>
    </div>
    <div>
      <div class="meta">H3 · 22px · weight 600 · -0.01em</div>
      <h3 style="margin:8px 0 0;">The quick brown fox</h3>
    </div>
  </div>
</div>
```

Use the actual font via the CSS token. Show meta info above each sample.

---

## Template: Buttons with ALL states

This is critical — show every state visually, side by side.

```html
<!-- buttons.html -->
<div class="card">
  <div class="mini-label" style="margin-bottom:20px;">Primary Button — All States</div>
  <div class="row" style="gap:16px; flex-wrap:wrap;">

    <!-- Rest -->
    <div style="text-align:center;">
      <button style="
        background:var(--accent);
        color:white;
        font-family:var(--font-body);
        font-weight:700;
        font-size:16px;
        padding:16px 28px;
        border:none;
        border-radius:var(--radius-md);
        box-shadow:var(--glow-accent);
        cursor:pointer;
      ">Get Started</button>
      <div class="meta" style="margin-top:8px;">Rest</div>
    </div>

    <!-- Hover (simulated) -->
    <div style="text-align:center;">
      <button style="
        background:var(--accent-hover);
        color:white;
        font-family:var(--font-body);
        font-weight:700;
        font-size:16px;
        padding:16px 28px;
        border:none;
        border-radius:var(--radius-md);
        box-shadow:var(--glow-accent-hover);
        transform:translateY(-1px);
        cursor:pointer;
      ">Get Started</button>
      <div class="meta" style="margin-top:8px;">Hover</div>
    </div>

    <!-- Focus -->
    <div style="text-align:center;">
      <button style="
        background:var(--accent);
        color:white;
        font-family:var(--font-body);
        font-weight:700;
        font-size:16px;
        padding:16px 28px;
        border:none;
        border-radius:var(--radius-md);
        box-shadow:var(--glow-accent);
        outline:2px solid var(--accent);
        outline-offset:3px;
        cursor:pointer;
      ">Get Started</button>
      <div class="meta" style="margin-top:8px;">Focus</div>
    </div>

    <!-- Active/Pressed -->
    <div style="text-align:center;">
      <button style="
        background:var(--accent-pressed);
        color:white;
        font-family:var(--font-body);
        font-weight:700;
        font-size:16px;
        padding:16px 28px;
        border:none;
        border-radius:var(--radius-md);
        box-shadow:var(--glow-accent);
        cursor:pointer;
      ">Get Started</button>
      <div class="meta" style="margin-top:8px;">Pressed</div>
    </div>

    <!-- Disabled -->
    <div style="text-align:center;">
      <button style="
        background:var(--accent);
        color:white;
        font-family:var(--font-body);
        font-weight:700;
        font-size:16px;
        padding:16px 28px;
        border:none;
        border-radius:var(--radius-md);
        opacity:0.4;
        cursor:not-allowed;
      ">Get Started</button>
      <div class="meta" style="margin-top:8px;">Disabled</div>
    </div>

    <!-- Loading -->
    <div style="text-align:center;">
      <button style="
        background:var(--accent);
        color:white;
        font-family:var(--font-body);
        font-weight:700;
        font-size:16px;
        padding:16px 28px;
        border:none;
        border-radius:var(--radius-md);
        box-shadow:var(--glow-accent);
        cursor:wait;
        min-width:160px;
      ">Loading...</button>
      <div class="meta" style="margin-top:8px;">Loading</div>
    </div>
  </div>

  <!-- Also include an INTERACTIVE button that responds to real hover/focus/active -->
  <div class="mini-label" style="margin:32px 0 16px;">Interactive (try hovering)</div>
  <style>
    .btn-live {
      background: var(--accent);
      color: white;
      font-family: var(--font-body);
      font-weight: 700;
      font-size: 16px;
      padding: 16px 28px;
      border: none;
      border-radius: var(--radius-md);
      box-shadow: var(--glow-accent);
      cursor: pointer;
      transition: all 0.2s ease;
    }
    .btn-live:hover {
      background: var(--accent-hover);
      box-shadow: var(--glow-accent-hover);
      transform: translateY(-1px);
    }
    .btn-live:focus {
      outline: 2px solid var(--accent);
      outline-offset: 3px;
    }
    .btn-live:active {
      background: var(--accent-pressed);
      transform: translateY(0);
    }
  </style>
  <button class="btn-live">Get Started</button>
</div>
```

---

## Template: Form inputs with ALL states

```html
<!-- form-input.html -->
<div class="card">
  <div class="mini-label" style="margin-bottom:20px;">Form Input — All States</div>
  <div class="col" style="gap:20px; max-width:400px;">

    <!-- Rest -->
    <div>
      <div class="meta" style="margin-bottom:6px;">Rest</div>
      <input type="text" placeholder="Your email" style="
        width:100%;box-sizing:border-box;
        background:var(--input-bg);
        border:1px solid var(--hairline-strong);
        color:white;
        font-family:var(--font-body);
        font-size:16px;font-weight:500;
        padding:16px 18px;
        border-radius:var(--radius-md);
      ">
    </div>

    <!-- Focus (simulated) -->
    <div>
      <div class="meta" style="margin-bottom:6px;">Focus</div>
      <input type="text" value="matt@example.com" style="
        width:100%;box-sizing:border-box;
        background:var(--input-bg-focus);
        border:1px solid var(--accent);
        color:white;
        font-family:var(--font-body);
        font-size:16px;font-weight:500;
        padding:16px 18px;
        border-radius:var(--radius-md);
      ">
    </div>

    <!-- Error -->
    <div>
      <div class="meta" style="margin-bottom:6px;">Error</div>
      <input type="text" value="not-an-email" style="
        width:100%;box-sizing:border-box;
        background:var(--input-bg);
        border:1px solid #E53E3E;
        color:white;
        font-family:var(--font-body);
        font-size:16px;font-weight:500;
        padding:16px 18px;
        border-radius:var(--radius-md);
      ">
      <div style="color:#E53E3E;font-size:13px;margin-top:6px;font-family:var(--font-body);">Please enter a valid email address</div>
    </div>

    <!-- Success -->
    <div>
      <div class="meta" style="margin-bottom:6px;">Success</div>
      <input type="text" value="matt@example.com" style="
        width:100%;box-sizing:border-box;
        background:var(--input-bg);
        border:1px solid #38A169;
        color:white;
        font-family:var(--font-body);
        font-size:16px;font-weight:500;
        padding:16px 18px;
        border-radius:var(--radius-md);
      ">
    </div>

    <!-- Disabled -->
    <div>
      <div class="meta" style="margin-bottom:6px;">Disabled</div>
      <input type="text" placeholder="Not available" disabled style="
        width:100%;box-sizing:border-box;
        background:rgba(0,0,0,0.2);
        border:1px solid var(--hairline);
        color:var(--muted);
        font-family:var(--font-body);
        font-size:16px;font-weight:500;
        padding:16px 18px;
        border-radius:var(--radius-md);
        opacity:0.5;
        cursor:not-allowed;
      ">
    </div>
  </div>
</div>
```

---

## Template: Cards with hover

```html
<!-- cards.html -->
<div class="card">
  <div class="mini-label" style="margin-bottom:20px;">Card — Rest → Hover</div>
  <style>
    .demo-card {
      background: var(--card-bg);
      border: 1px solid var(--hairline);
      border-radius: var(--radius-lg);
      padding: 28px;
      transition: all 0.3s var(--ease-standard);
      max-width: 300px;
    }
    .demo-card:hover {
      border-color: rgba(var(--accent-rgb, 235,122,46), 0.4);
      transform: translateY(-4px);
      background: var(--card-bg-hover);
      box-shadow: var(--shadow-card-hover);
    }
    .demo-card h3 { margin: 0 0 8px; }
    .demo-card p { margin: 0; font-size: 15px; opacity: 0.8; }
  </style>
  <div class="row" style="gap:24px;">
    <div>
      <div class="meta" style="margin-bottom:8px;">Hover me ↓</div>
      <div class="demo-card">
        <h3>Card Title</h3>
        <p>Card description text that explains what this card contains.</p>
      </div>
    </div>
  </div>
</div>
```

---

## Template: Gradient / Atmosphere

```html
<!-- atmosphere.html -->
<div class="card" style="height:300px; position:relative;">
  <div style="
    position:absolute;inset:0;
    background: var(--grad-atmosphere);
    pointer-events:none;
  "></div>
  <div style="position:relative;z-index:1;">
    <div class="mini-label" style="margin-bottom:12px;">Atmosphere Gradient</div>
    <div class="meta">
      Violet glow top-left at ~10% opacity<br>
      Accent glow bottom-right at ~8% opacity<br>
      Always present, never consciously visible
    </div>
  </div>
</div>
```

---

## Template: Motion (interactive)

```html
<!-- motion.html -->
<div class="card">
  <div class="mini-label" style="margin-bottom:20px;">Motion — Interactive Demo</div>
  <style>
    @keyframes btn-pulse {
      0% { box-shadow: var(--glow-accent), 0 0 0 0 rgba(var(--accent-rgb,235,122,46),0.4); }
      70% { box-shadow: var(--glow-accent), 0 0 0 15px rgba(var(--accent-rgb,235,122,46),0); }
      100% { box-shadow: var(--glow-accent), 0 0 0 0 rgba(var(--accent-rgb,235,122,46),0); }
    }
    .pulse-btn {
      /* ... button styles ... */
      animation: btn-pulse 3s infinite;
    }
    .pulse-btn:hover { animation: none; }
  </style>

  <div class="col" style="gap:24px;">
    <div>
      <div class="meta" style="margin-bottom:8px;">CTA Pulse (stops on hover)</div>
      <button class="pulse-btn">Watch the glow</button>
    </div>
    <div>
      <div class="meta" style="margin-bottom:8px;">Card Lift (hover to see)</div>
      <div class="demo-card">Hover me for the lift effect</div>
    </div>
  </div>
</div>
```

---

## Standalone HTML structure

The `standalone.html` file combines all previews into one browsable page:

```html
<!doctype html>
<html><head>
  <meta charset="utf-8">
  <title>[Brand] Design System</title>
  <link rel="stylesheet" href="colors_and_type.css">
  <style>
    /* Navigation sidebar + section layout */
    body { display: flex; margin: 0; min-height: 100vh; }
    nav { width: 220px; padding: 24px; position: sticky; top: 0; height: 100vh; overflow-y: auto; border-right: 1px solid var(--hairline); }
    main { flex: 1; padding: 48px; max-width: 900px; }
    section { margin-bottom: 80px; }
    nav a { display: block; padding: 6px 0; color: var(--muted); text-decoration: none; font-size: 14px; }
    nav a:hover { color: var(--accent); }
    nav .section-title { color: var(--ghost); font-weight: 700; font-size: 12px; letter-spacing: 0.15em; text-transform: uppercase; margin: 20px 0 8px; }
  </style>
</head>
<body>
  <nav>
    <div class="section-title">Colors</div>
    <a href="#colors-foundation">Foundation</a>
    <a href="#colors-accents">Accents</a>
    <!-- ... all sections ... -->
  </nav>
  <main>
    <section id="colors-foundation">
      <h2>Foundation Colors</h2>
      <!-- Inline the content from colors-foundation.html -->
    </section>
    <!-- ... all sections ... -->
  </main>
</body></html>
```

Each section inlines the content (not the full HTML boilerplate) from the corresponding preview file. The standalone file uses the same CSS tokens, so everything renders consistently.
