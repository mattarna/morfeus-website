# The AI Design System Blueprint

**How to make any AI build you a complete, production-ready design system from scratch.**

> This document is a universal framework. Follow it step by step and you'll end up with a design system that works for humans (who need to see it) and for AI (who needs to build with it). No design experience required. No code experience required. Just decisions.

---

## How to use this document

This is both a guide for you and an instruction set for your AI. Here's the process:

1. **You** read each section and make the decisions it asks for (colors, fonts, tone, etc.)
2. **You** feed those decisions to your AI (Claude, GPT, or whatever you use)
3. **The AI** generates each layer of the design system following the structure below
4. **You** review the visual previews, give feedback, iterate
5. **You** end up with a folder of files that any AI can read to generate perfectly on-brand assets forever

The result is a self-contained system with three types of files: markdown documentation (the AI reads this), CSS tokens (code drops this in), and HTML previews (you open these in a browser to see everything visually).

---

## What a design system is (and what it isn't)

A design system is a set of rules and building blocks that ensure everything you create looks like it belongs to the same brand. It's the difference between "I made this in Canva at 2am" and "this looks like a real company."

**It IS:**
- A single source of truth for colors, fonts, spacing, components, and tone
- A set of constraints that make decisions faster (not slower)
- A living document that evolves with your brand

**It is NOT:**
- A logo (that's one asset inside it)
- A style guide PDF that nobody reads (it has to be functional)
- A Figma file (though it can feed one)
- Something you need a designer for (you need taste and decisions)

**Why it matters for AI:** Without a design system, every time you ask an AI to create something, it starts from zero. It guesses your colors, picks random fonts, invents spacing. With a design system, every output is automatically on-brand because the AI has explicit rules to follow.

---

## The 9 layers

A complete design system has 9 layers. Each one builds on the previous. Skip none.

| # | Layer | What it defines | Why it matters |
|---|---|---|---|
| 1 | Brand Foundation | Identity, tone, what you are and aren't | Everything else flows from this |
| 2 | Color System | Every color, its role, and dominance rules | Color is 80% of brand recognition |
| 3 | Typography | Font families, hierarchy, sizing, spacing | Type is the other 20% |
| 4 | Spacing & Layout | Breakpoints, grid, rhythm, max-widths | Prevents "this looks off" syndrome |
| 5 | Components | Buttons, cards, inputs, badges — with ALL states | The building blocks of every page |
| 6 | Motion & Animation | What moves, how, and how fast | Gives the brand personality without chaos |
| 7 | Gradients & Atmosphere | Visual depth, signature effects | The "feel" layer that makes it premium |
| 8 | Iconography & Assets | Icon style, logo variants, image treatment | The visual vocabulary |
| 9 | Content Rules | Copy tone, language, casing, punctuation | Words are design too |

---

## Layer 1: Brand Foundation

This is the DNA. Everything else is an expression of what you decide here.

### What to define

**Identity statement (1-2 sentences).** Not a mission statement. Not a tagline. A description of what this brand feels like when someone encounters it. Example: "Competence with energy. You know what you're doing and you show it without shouting."

**What this brand IS (3-5 attributes).** These are adjectives with teeth. Not "innovative" or "dynamic" (meaningless). Think: dark, premium, authoritative, warm, concrete, clean, technical, playful, minimal, bold, quiet, loud. Pick the ones that are true and specific to you.

**What this brand is NOT (3-5 anti-attributes).** Equally important. These tell the AI what to avoid. Examples: "Not corporate. Not hype. Not a generic infobiz template. Not a copy of [competitor]."

**Surfaces.** List every surface this design system must serve and what each one does:

| Surface | Role |
|---|---|
| Landing page | Single goal: collect the email |
| Sales page | Long-form, repeated CTA, overcome objections |
| Email | Inverted colors? Same colors? What's the context? |
| Slides / Deck | Presentation format, aspect ratio |
| Social media | Platform, format, speed of consumption |
| PDF / Documents | Print-friendly? Digital only? |

### What to tell your AI

```
Here is my brand foundation. Use this as the lens for every design decision:

Identity: [your identity statement]
Attributes: [your 3-5 attributes]
Anti-attributes: [your 3-5 anti-attributes]
Surfaces: [your surface table]

Every visual choice you make must pass this test: does it reinforce the identity statement? If not, change it.
```

### Common mistakes
- Being too vague ("modern and clean" describes 10,000 brands)
- Not defining anti-attributes (the AI needs to know what to avoid as much as what to do)
- Forgetting surfaces (if you don't list email, you won't get email-specific rules)

---

## Layer 2: Color System

Color is the most visible part of your brand. Get this right and everything else falls into place.

### 2.1 Structure

Every color in your system has exactly one job. Organize them into these categories:

**Foundation colors (backgrounds).** 2-4 colors that form the "bed" your content sits on. If your brand is dark, these are near-black shades with subtle differences. If light, these are near-white shades. Never just one flat color — you need variation for depth.

```
Example (dark brand):
| Token        | HEX     | Role                                    |
|--------------|---------|-----------------------------------------------|
| night        | #0B0B0C | Primary background. Almost black.             |
| deep-space   | #0F0E1A | Alternate sections, gradient base             |
| dusk         | #1A1535 | Depth layer, special cards, photo placeholders|
```

```
Example (light brand):
| Token        | HEX     | Role                                    |
|--------------|---------|-----------------------------------------------|
| snow         | #FAFBFC | Primary background. Not pure white.           |
| cloud        | #F0F2F5 | Alternate sections, card backgrounds          |
| mist         | #E8EBF0 | Depth layer, input backgrounds                |
```

**Primary accent (1 color + hover + pressed states).** This is your action color — the one that says "click here" or "look at this." It appears on CTAs, highlights, and key numbers. One color, three states minimum.

```
| Token          | HEX     | Role              |
|----------------|---------|-------------------|
| accent         | #EB7A2E | Rest state        |
| accent-hover   | #F09A5C | Hover — lighter   |
| accent-pressed | #D4652A | Active — darker   |
```

**Secondary accent (1-2 colors).** Structural, organizational. Used for labels, tags, section markers. Never competes with the primary accent for attention.

**Text colors (3 levels).** You need exactly three: primary (headlines), secondary (body), tertiary (captions, metadata). On dark backgrounds these go from white to light grey to medium grey. On light backgrounds, from near-black to dark grey to medium grey.

```
Dark background text:
| Token  | HEX     | Role                           |
|--------|---------|--------------------------------|
| white  | #FFFFFF | Headlines, strong emphasis      |
| ghost  | #E4E7F0 | Body text, at opacity 0.85-0.90|
| muted  | #9B9BB0 | Captions, labels, metadata     |

Light background text:
| Token  | HEX     | Role                           |
|--------|---------|--------------------------------|
| ink    | #1A1A2E | Headlines, strong emphasis      |
| body   | #3D3D56 | Body text                       |
| subtle | #8888A0 | Captions, labels, metadata     |
```

**Utility colors.** Borders (hairlines), card backgrounds, input backgrounds — typically defined as rgba values so they adapt to any background.

### 2.2 Dominance rules

This is what separates amateur from professional. Define exact percentages of how much visual space each color category occupies:

```
~85% Foundation (backgrounds) — the base dominates always
~10% Text — the content
~4%  Primary accent — action only, never decoration
~1%  Secondary accent — structure, atmosphere
```

Write a hard cap: "If the primary accent occupies more than X% of the visible surface, you've overused it." This constraint is what keeps the AI from making everything orange (or whatever your accent is).

### 2.3 Light mode / inverted context

If any of your surfaces uses a light background (email, PDF, print, documentation), you need an explicit inverted token set. Don't leave it to interpretation.

Define:
- Which foundation tokens map to which light equivalents
- Which text tokens flip
- Whether accents change or stay the same
- Which logo variant to use on light

```
| Dark mode token | Light mode equivalent | HEX     |
|-----------------|----------------------|---------|
| night           | snow                 | #FAFBFC |
| deep-space      | cloud                | #F0F2F5 |
| white (text)    | ink                  | #1A1A2E |
| ghost (text)    | body                 | #3D3D56 |
| orange (accent) | orange (same)        | #EB7A2E |
```

### 2.4 Accessibility

State the minimum contrast ratios you enforce:
- Body text on background: 4.5:1 minimum (WCAG AA), 7:1 target (AAA)
- Heading text on background: 3:1 minimum
- Interactive elements: 3:1 against adjacent colors

Tell the AI to verify contrast mathematically before finalizing any color pairing.

### What to tell your AI

```
Here is my color system. Use these tokens exclusively — never invent new colors.

[paste your complete color table]

Dominance rule: [your percentages]
Hard cap: [your accent limit]
Light mode mapping: [your inverted tokens, if applicable]
Contrast: enforce WCAG AA minimum (4.5:1 body, 3:1 headings).
```

---

## Layer 3: Typography

Three fonts maximum. Each with one job. No exceptions.

### 3.1 Font stack

| Role | What it does | Where it appears | Example families |
|---|---|---|---|
| Display | Headlines, hero text, big numbers | H1, H2, H3, feature numbers | Clash Display, Cabinet Grotesk, General Sans |
| Accent (optional) | Emphasis inside headlines — 1-3 words max | Colored keywords within display text | Playfair Display Italic, Fraunces Italic, DM Serif Display |
| Body | Everything else | Paragraphs, buttons, labels, forms, captions | Satoshi, Inter, DM Sans, Plus Jakarta Sans |

**The accent font is optional but powerful.** It creates typographic contrast — a serif word inside a sans-serif headline, or an italic flourish against geometric text. Rules if you use one:
- Only in italic
- Only 1-3 words per headline
- Always in a different color from surrounding text (typically the primary accent)
- Never in body, buttons, labels, or captions
- Never as the sole font of a headline

**Self-hosting fonts is mandatory.** Your design system must include the actual font files (variable TTF or WOFF2), not CDN links. This ensures: (a) the AI can generate assets offline, (b) no dependency on external services, (c) consistent rendering. Include `@font-face` declarations in your CSS tokens file.

### 3.2 Hierarchy and sizing

Define every level explicitly. Leave nothing to interpretation.

```
| Element           | Font    | Weight | Size                      | Line-height | Letter-spacing | Color         |
|-------------------|---------|--------|---------------------------|-------------|----------------|---------------|
| H1 (hero)         | Display | 600    | clamp(40px, 6vw, 68px)    | 1.02-1.10   | -0.025em       | primary text  |
| H1 accent words   | Accent  | 500    | inherits from H1          | normal      | normal         | primary accent|
| H2 (section)      | Display | 600    | clamp(32px, 4.5vw, 48px)  | 1.05-1.10   | -0.02em        | primary text  |
| H3 (card/subsec.) | Display | 600    | 22-24px                   | 1.15        | -0.01em        | primary text  |
| Body              | Body    | 400    | 17-18px                   | 1.55-1.65   | normal         | secondary text|
| Body (card)       | Body    | 400    | 16px (minimum)            | 1.55        | normal         | secondary text|
| Label / Tag       | Body    | 700    | 12-13px                   | 1.3         | 0.12-0.20em    | secondary accent, uppercase |
| CTA button        | Body    | 700    | 16-17px                   | 1.0         | normal         | white on accent|
| Caption / Micro   | Body    | 400    | 13-14px                   | 1.3         | normal         | tertiary text |
```

**Critical rule:** Body text never drops below 16px on desktop, 15px on mobile. Readability beats aesthetics, always.

### 3.3 Responsive type scale

Define how typography adapts across breakpoints. Use `clamp()` for fluid scaling where possible, and explicit overrides where needed.

```
| Element | Mobile (<640px) | Tablet (640-1024px) | Desktop (>1024px) |
|---------|-----------------|---------------------|-------------------|
| H1      | 36-40px         | 48-56px             | 56-68px           |
| H2      | 28-32px         | 36-42px             | 42-48px           |
| H3      | 20-22px         | 22px                | 22-24px           |
| Body    | 16px            | 17px                | 17-18px           |
| Caption | 13px            | 13px                | 13-14px           |
```

### What to tell your AI

```
Here are my fonts. Use ONLY these — never substitute.

Display: [name] — for all headings
Accent: [name] — ONLY for 1-3 colored keywords inside headings, always italic
Body: [name] — for everything else

Font files are in assets/fonts/. @font-face declarations are in colors_and_type.css.

[paste your complete hierarchy table]
[paste your responsive type scale]

Hard rule: body text minimum 16px desktop, 15px mobile. No exceptions.
```

---

## Layer 4: Spacing & Layout

Spacing is what makes design feel "right" without anyone being able to explain why. It's the invisible structure.

### 4.1 Breakpoints

Define explicit breakpoints. Every surface in your system must know how to behave at each size.

```
| Name    | Min-width | Target devices              |
|---------|-----------|----------------------------|
| mobile  | 0px       | Phones, portrait            |
| tablet  | 640px     | Tablets, large phones landscape |
| desktop | 1024px    | Laptops, desktops           |
| wide    | 1440px    | Large monitors (optional)   |
```

**Mobile-first approach:** Base styles target mobile. Each breakpoint adds complexity upward. Tell the AI: "Write CSS mobile-first. Base rules are for the smallest screen. Use `@media (min-width: ...)` to add for larger screens."

### 4.2 Spacing scale

Use a consistent scale. Not random numbers — a system.

```
| Token      | Value | Usage example                          |
|------------|-------|----------------------------------------|
| --space-1  | 4px   | Tight gaps, icon-to-text               |
| --space-2  | 8px   | Small internal padding                 |
| --space-3  | 12px  | Between related items                  |
| --space-4  | 16px  | Standard gap, input padding            |
| --space-5  | 20px  | Card internal padding (mobile)         |
| --space-6  | 24px  | Card gap, side padding                 |
| --space-8  | 32px  | Card internal padding (desktop)        |
| --space-10 | 40px  | Between sections (mobile)              |
| --space-12 | 48px  | Section label to content               |
| --space-16 | 64px  | Section padding (mobile)               |
| --space-20 | 80px  | Section padding (desktop, tight)       |
| --space-24 | 96px  | Section padding (desktop, standard)    |
| --space-30 | 120px | Section padding (desktop, breathing)   |
```

### 4.3 Layout constraints

```
| Constraint     | Value   | Why                                    |
|----------------|---------|----------------------------------------|
| Content max    | 1120px  | Wide enough for 3 columns, narrow enough to read |
| Side padding   | 24px    | Breathing room on mobile               |
| Prose max      | 680px   | Optimal reading width (~65 characters)  |
| One H1/page    | —       | One primary message per page            |
| One CTA/viewport| —      | One action per screen                   |
```

### 4.4 Responsive spacing

```
| Context              | Mobile       | Desktop       |
|----------------------|-------------|---------------|
| Section vertical pad | 60-80px     | 80-120px      |
| Card gap             | 16px        | 20-24px       |
| Card internal pad    | 20-24px     | 28-32px       |
| Label to content     | 32-40px     | 48-64px       |
| Side padding         | 16-20px     | 24px          |
```

### What to tell your AI

```
Here are my spacing and layout rules:

Breakpoints: [your breakpoint table]
Approach: mobile-first. Base CSS = mobile. @media min-width for larger.

Spacing scale: [your scale]
Layout constraints: [your constraints]
Responsive spacing: [your responsive table]

Principle: spacing is rhythm, not math. Use the scale values, but prioritize visual breathing over pixel-perfect consistency.
```

---

## Layer 5: Components

These are the building blocks. Every page is assembled from these pieces. Each component needs ALL its states defined — not just how it looks at rest.

### 5.1 States checklist

Every interactive component must define these states:

| State | When | What changes |
|---|---|---|
| Rest | Default, no interaction | Base appearance |
| Hover | Cursor over (desktop) | Visual feedback — color shift, lift, glow |
| Focus | Keyboard navigation / tab | Visible focus ring, accessibility |
| Active / Pressed | Mouse down / tap | Pressed appearance — darker, no lift |
| Disabled | Not interactive | Reduced opacity, no pointer, no glow |
| Loading | Waiting for response | Spinner or pulse, text may change |
| Error | Validation failed | Red/warning color, error message |
| Success | Action completed | Green/confirmation color, check icon |

### 5.2 Buttons

The primary interactive element. Define at minimum: primary, secondary (outline/ghost), and text-only variants.

```css
/* === PRIMARY BUTTON === */

/* Rest */
background: var(--accent);
color: white;
font-family: var(--font-body);
font-weight: 700;
font-size: 16px;
padding: 16px 28px;
border: none;
border-radius: var(--radius-md); /* 10px */
box-shadow: var(--glow-accent); /* 0 4px 20px rgba(accent, 0.35) */
cursor: pointer;
transition: all 0.2s ease;

/* Hover */
background: var(--accent-hover);
box-shadow: var(--glow-accent-hover); /* stronger glow */
transform: translateY(-1px);

/* Focus (accessibility) */
outline: 2px solid var(--accent);
outline-offset: 3px;

/* Active / Pressed */
background: var(--accent-pressed);
transform: translateY(0);
box-shadow: var(--glow-accent); /* back to base glow */

/* Disabled */
opacity: 0.4;
cursor: not-allowed;
pointer-events: none;
box-shadow: none;
transform: none;

/* Loading */
pointer-events: none;
/* Replace text with spinner or show spinner alongside text */
/* Button width stays fixed to prevent layout shift */

/* === SECONDARY BUTTON (ghost/outline) === */

/* Rest */
background: transparent;
color: var(--accent);
border: 1px solid rgba(accent, 0.4);
/* No glow */

/* Hover */
background: rgba(accent, 0.08);
border-color: rgba(accent, 0.6);

/* === TEXT BUTTON === */

/* Rest */
background: none;
color: var(--accent);
padding: 8px 4px;
border: none;
/* No glow, no border */

/* Hover */
color: var(--accent-hover);
```

### 5.3 Cards

```css
/* Rest — almost invisible */
background: rgba(255,255,255,0.03); /* or rgba(0,0,0,0.03) on light */
border: 1px solid rgba(255,255,255,0.06);
border-radius: var(--radius-lg); /* 14px */
padding: 28px 32px;
transition: all 0.3s var(--ease-standard);

/* Hover — comes alive */
border-color: rgba(accent, 0.4);
transform: translateY(-4px);
background: rgba(255,255,255,0.05);
box-shadow: 0 10px 30px rgba(0,0,0,0.3);

/* Focus (if interactive/clickable) */
outline: 2px solid var(--accent);
outline-offset: 2px;

/* Selected / Active (if toggleable) */
border-color: var(--accent);
background: rgba(accent, 0.06);
```

### 5.4 Form inputs

```css
/* Rest */
background: rgba(0,0,0,0.4); /* adjust for light: rgba(0,0,0,0.04) */
border: 1px solid rgba(255,255,255,0.12);
color: var(--white);
font-family: var(--font-body);
font-size: 16px;
font-weight: 500;
padding: 16px 18px;
border-radius: var(--radius-md); /* 10px */
transition: border-color 0.2s ease, background 0.2s ease;

/* Placeholder */
color: var(--muted);

/* Focus */
border-color: var(--accent);
background: rgba(0,0,0,0.6);
outline: none; /* custom focus via border, not browser outline */

/* Error */
border-color: #E53E3E; /* or your error red */
/* Show error message below in small red text */

/* Success */
border-color: #38A169; /* or your success green */
/* Optional: show check icon inside input */

/* Disabled */
opacity: 0.5;
cursor: not-allowed;
background: rgba(0,0,0,0.2);
```

### 5.5 Badges and tags

```css
/* Badge (important label, e.g. "Free Webinar") */
padding: 8px 16px;
border-radius: var(--radius-pill); /* 100px */
background: rgba(accent, 0.10);
border: 1px solid rgba(accent, 0.25);
color: var(--accent);
font-size: 13px;
font-weight: 700;
letter-spacing: 0.08em;
text-transform: uppercase;

/* Tag (structural label, e.g. "PROJECTS") */
padding: 4px 10px;
border-radius: var(--radius-sm); /* 6px */
background: rgba(secondary-accent, 0.12);
border: 1px solid rgba(secondary-accent, 0.25);
color: var(--secondary-accent);
font-size: 12px;
font-weight: 700;
letter-spacing: 0.05em;
```

### 5.6 Check icon (for feature/benefit lists)

```css
width: 26px;
height: 26px;
border-radius: 6px;
background: rgba(accent, 0.1);
border: 1px solid var(--accent);
color: var(--accent);
font-size: 13px;
font-weight: 700;
display: flex;
align-items: center;
justify-content: center;
/* Content: ✓ */
```

### 5.7 Separators

```css
height: 1px;
background: rgba(255,255,255,0.06); /* hairline */
/* No margin built in — spacing handled by parent */
```

### 5.8 Form card (special container)

```css
background: rgba(255,255,255,0.03);
border: 1px solid rgba(255,255,255,0.08);
border-radius: var(--radius-xl); /* 16px */
padding: 28px;
backdrop-filter: blur(10px);
/* Optional: gradient border via CSS mask on ::before pseudo-element */
```

### What to tell your AI

```
Here are my components. Every interactive element MUST have all applicable states: rest, hover, focus, active, disabled, loading, error, success.

[paste your component CSS]

Rules:
- Never invent a new component without defining all its states
- Focus states are mandatory for accessibility (visible outline or equivalent)
- Disabled = reduced opacity + no pointer + no glow/shadow
- Loading = same dimensions as rest state (no layout shift)
- Error/success colors: [define your semantic colors]
```

---

## Layer 6: Motion & Animation

Motion gives your brand personality. But undisciplined motion makes it feel cheap.

### 6.1 Timing tokens

```css
--ease-standard: cubic-bezier(0.4, 0, 0.2, 1); /* smooth decel */
--ease-in:       cubic-bezier(0.4, 0, 1, 1);    /* accelerate out */
--ease-out:      cubic-bezier(0, 0, 0.2, 1);    /* decelerate in */
--dur-fast:  0.15s;  /* micro-interactions: color change, opacity */
--dur-base:  0.2s;   /* standard: hover, focus, toggle */
--dur-slow:  0.3s;   /* structural: card lift, expand, collapse */
--dur-max:   0.4s;   /* absolute ceiling — nothing takes longer */
```

### 6.2 What moves and what doesn't

| Element | Animation | Timing | Notes |
|---|---|---|---|
| Button hover | Color shift + translateY(-1px) + glow intensifies | 0.2s ease | Subtle lift |
| Button press | Color darkens + translateY(0) | 0.1s ease | Immediate |
| Card hover | Border color + translateY(-4px) + shadow appears | 0.3s standard | The "dormant → alive" metaphor |
| Input focus | Border color change | 0.2s ease | Clean transition |
| Link hover | Color shift only | 0.2s ease | No movement |
| CTA pulse | Shadow ring expanding | 3s infinite | Stops on hover |
| Badge dot | Opacity pulse | 2s infinite | Extremely subtle |

### 6.3 Forbidden motion

Write this explicitly for your AI. These are the things that make websites feel amateurish:

- **No scroll-triggered fade-ins.** Content is there when you scroll to it. Period.
- **No parallax.** Ever.
- **No bouncy springs or elastic easing.** This isn't a mobile app.
- **No decorative loaders.** If something loads, show a skeleton or nothing.
- **No section-entry animations.** No "slide in from left" as you scroll.
- **Nothing longer than 0.4s.** If the user can consciously watch it happen, it's too slow.
- **Nothing shakes. Nothing bounces. Nothing wobbles.**

### What to tell your AI

```
Motion rules:

Timing tokens: [your timing values]
Animation map: [your element-to-animation table]

FORBIDDEN: [your forbidden list]

Principle: motion exists to give feedback, not to entertain. If you can't explain what information the animation conveys, remove it.
```

---

## Layer 7: Gradients & Atmosphere

This is the "feel" layer. It's what makes a page feel premium vs. flat.

### 7.1 Types of gradients

Define each gradient by name, CSS value, and exact usage rules:

**Signature gradient** — the brand's visual fingerprint. Used very sparingly.
```css
--grad-signature: linear-gradient(135deg, [secondary-accent] 0%, [primary-accent] 100%);
/* Usage: gradient text on hero headline, logo mark, one decorative element max */
/* NEVER as background of a large area */
/* NEVER more than one instance per screen */
```

**Atmosphere gradient** — always present, never visible. Creates depth.
```css
--grad-atmosphere:
  radial-gradient(ellipse at 15% 10%, rgba(secondary-accent, 0.10) 0%, transparent 45%),
  radial-gradient(ellipse at 85% 90%, rgba(primary-accent, 0.08) 0%, transparent 50%);
/* Usage: fixed overlay on body. The user feels it, doesn't see it. */
/* Opacity ALWAYS below 0.12. If you can clearly see it, it's too strong. */
```

**Subtle border gradient** — for special containers.
```css
--grad-border: linear-gradient(135deg, rgba(secondary-accent, 0.3), rgba(primary-accent, 0.2));
/* Usage: 1px border via CSS mask technique on form cards, special sections */
```

**Section alternate** — creates vertical rhythm between sections.
```css
--grad-section: linear-gradient(180deg, transparent 0%, rgba(alt-bg, 0.6) 50%, transparent 100%);
/* Usage: alternate sections. Fades in and out — never a hard cut. */
```

### 7.2 Rules

- One strong gradient per screen maximum (the signature gradient draws too much attention)
- Atmosphere gradients are ALWAYS below opacity 0.12
- Gradients never replace solid colors for text or icons
- All linear gradients use the same angle (135deg = diagonal top-left to bottom-right) for consistency
- Radial gradients are always asymmetric (never centered)

### What to tell your AI

```
Here are my gradients. Use these exact values — never invent new gradients.

Signature gradient: [your CSS]
Usage: gradient text on hero, logo mark. ONE instance per screen max. Never as large-area background.

Atmosphere gradient: [your CSS]
Usage: fixed overlay on body. Always present. Opacity always below 0.12.

Border gradient: [your CSS]
Usage: 1px border via mask technique on form cards and special sections.

Section alternate: [your CSS]
Usage: vertical rhythm between sections. Fade in/out, never hard cut.

Rules: same angle (135deg) for all linear gradients. Radials always asymmetric. If you can clearly see the atmosphere gradient, it's too strong.
```

---

## Layer 8: Iconography & Assets

### 8.1 Icon approach

Define your icon philosophy. Options:

**Option A: No custom icon set (recommended for most brands).** The brand relies on type, space, and color. Icons are used only when text alone can't communicate. When needed, specify a default icon library (e.g., Lucide, Phosphor, Heroicons) with exact settings:

```
Library: [name]
Stroke width: [e.g., 1.5px]
Size: [e.g., 24px box]
Style: [e.g., rounded joins, rounded caps]
Color: inherits from context
```

**Option B: Custom icon set.** If you have one, include the files and specify the grid, stroke, corner radius, and naming convention.

### 8.2 Logo variants

You need multiple variants of your logo for different contexts. Organize them in a matrix:

| Variant | Background | File | Usage |
|---|---|---|---|
| White | Dark backgrounds | `m-w.png` | Header, hero, dark sections |
| Black | Light backgrounds | `m-b.png` | Email, PDF, light sections |
| Color | Either | `m-c.png` | Special emphasis, accent slides |

For each color variant, you may need multiple forms:

| Form | Description | Usage |
|---|---|---|
| Symbol only | Just the mark | Favicon, small spaces, footer |
| Horizontal | Symbol + wordmark side by side | Header, wide spaces |
| Stacked | Symbol above wordmark | Slides, square formats |

Name files systematically: `[brand]-[color][form].[ext]`
Example: `m-w.png` (symbol, white), `m-w2.png` (horizontal, white), `m-w3.png` (stacked, white)

### 8.3 Image treatment

Define how photos and screenshots are styled in your system:

```
Photos (portraits):
- Aspect ratio: 4:5
- Border-radius: 16-20px
- Border: 1px rgba(255,255,255,0.1)
- Optional: subtle accent glow behind

Screenshots:
- Border-radius: 12-14px
- Border: 1px rgba(255,255,255,0.08)
- Shadow: 0 10px 40px rgba(0,0,0,0.4)
- Never a flat mid-grey placeholder
```

### 8.4 Emoji rules

Be explicit:
- Never in layout, UI chrome, buttons, or headlines
- Acceptable in body copy when it clarifies (e.g., "📍 Online" in a meta row)
- Default is OFF — only use when it adds information

### What to tell your AI

```
Iconography rules:

Icon library: [name, e.g., Lucide] — stroke [width], size [px], style [rounded/sharp]
Usage: sparingly. Prefer type + space + color over icons. The brand leans on typography.

Logo variants: [list your files and their contexts]
- White variants for dark backgrounds
- Black variants for light backgrounds
- Color variants for special emphasis

Image treatment:
- Photos: [your photo rules — aspect ratio, radius, border, glow]
- Screenshots: [your screenshot rules — radius, border, shadow]
- Emoji: never in layout/UI. Acceptable in body copy when it clarifies. Default OFF.
```

---

## Layer 9: Content Rules

Words are design. The way you write is as much a part of the brand as the colors.

### 9.1 Language & tone

```
Primary language: [e.g., Italian]
Register: [e.g., "tu" not "lei" — direct, personal]
Tone: [e.g., competent, direct, warm, not hype]
Verb preference: [e.g., concrete verbs — usare, generare, costruire — not "empower, unlock, leverage"]
```

### 9.2 Casing

```
Headlines: Sentence case (capitalize first word only)
Buttons: Sentence case
Labels/eyebrows: UPPERCASE with generous letter-spacing (0.12-0.20em)
Body: Standard sentence case
Proper nouns: Always as-is (your brand name, tool names)
```

**Rule:** Never a full sentence in uppercase. Uppercase is for short labels only (1-2 words).

### 9.3 Punctuation

```
Exclamation marks: One max, usually none. [If your brand has visual energy, the design carries it — the copy doesn't need to shout.]
Emphasis: Use the accent font instead of caps for emphasis.
Numbers: Always as numerals (3 modules, 60 min — not "three modules").
Dashes: Em-dashes with spaces " — " (European style).
```

### 9.4 Words to avoid

List them explicitly. These are the words that break your brand tone:

```
BANNED: finally, game-changer, you won't believe, revolutionary, unlock, empower,
        our mission is to, the future of, next-generation, cutting-edge
```

### 9.5 Examples

Always provide good AND bad examples. The AI learns from contrast.

```
GOOD:
- "Un evento Morfeus. Non un webinar qualunque."
- "Webinar gratuito · 60 min · Live"
- "Come usare Claude al massimo nel tuo lavoro"

BAD (never write this):
- "🚀 UNLOCK THE POWER OF CLAUDE!!! 🔥"
- "You won't believe what Claude can do…"
- "Our mission is to empower creators through AI"
```

### What to tell your AI

```
Content rules for all copy:

Language: [primary language]
Register: [formal/informal, you/tu/lei]
Tone: [your 3-4 tone words]
Verb preference: [concrete vs abstract]

Casing: [your rules]
Punctuation: [your rules]

BANNED words/phrases: [your list]

Good examples: [3-5 examples of correct tone]
Bad examples: [3-5 examples of what to never write]

Rule: every piece of copy must match the brand tone. If it could appear on any other brand's website without anyone noticing, it's too generic. Rewrite it.
```

---

## The File Structure

This is what your AI generates. Every file has a purpose. Nothing is decorative.

```
design_system/
│
├── README.md                       ← Index: what's in this folder, how to use it
├── BRAND_GUIDELINES.md             ← The canonical brand document (all 9 layers)
├── SKILL.md                        ← Agent manifest (tells AI how to use this system)
├── colors_and_type.css             ← CSS custom properties + @font-face + base styles
│
├── assets/
│   ├── fonts/                      ← Self-hosted variable font files (.ttf or .woff2)
│   │   ├── [Display]-Variable.ttf
│   │   ├── [Body]-Variable.ttf
│   │   ├── [Body]-VariableItalic.ttf
│   │   └── [Accent]-Italic-Variable.ttf  (if using accent font)
│   │
│   └── logo/                       ← All logo variants as PNG (or SVG)
│       ├── [brand]-w.png           (white, symbol)
│       ├── [brand]-w2.png          (white, horizontal)
│       ├── [brand]-w3.png          (white, stacked)
│       ├── [brand]-b.png           (black, symbol)
│       ├── [brand]-b2.png          (black, horizontal)
│       ├── [brand]-b3.png          (black, stacked)
│       └── ...
│
├── preview/                        ← HTML cards for human review (one per element)
│   ├── _card.css                   ← Shared styles for preview cards
│   ├── colors-foundation.html
│   ├── colors-accents.html
│   ├── colors-text.html
│   ├── colors-dominance.html
│   ├── type-display.html
│   ├── type-accent.html
│   ├── type-body.html
│   ├── type-scale.html
│   ├── spacing.html
│   ├── breakpoints.html
│   ├── radii.html
│   ├── shadows-and-glow.html
│   ├── buttons.html                ← Shows ALL states: rest, hover, focus, active, disabled, loading
│   ├── cards.html
│   ├── form-input.html             ← Shows ALL states: rest, focus, error, success, disabled
│   ├── badges-and-tags.html
│   ├── check-icon.html
│   ├── gradient-signature.html
│   ├── atmosphere.html
│   ├── logos.html
│   ├── iconography.html
│   └── motion.html                 ← Interactive: shows hover/press/pulse live
│
├── ui_kits/                        ← Production-ready component templates
│   └── [surface_name]/             ← One folder per surface
│       ├── index.html              ← Entry point
│       ├── [Component].jsx         ← React components (or plain HTML)
│       └── README.md               ← What this kit covers, how to use it
│
└── [standalone].html               ← Single-file version of entire design system for browsing
```

### File-by-file purpose

**README.md** — The operational index. Maps the folder, explains what each file does, summarizes the brand in scannable form. An AI reads this first to orient itself.

**BRAND_GUIDELINES.md** — The canonical source of truth. Contains ALL 9 layers with exact values, CSS snippets, and rules. This is what the AI consults for every design decision. Written in markdown so any AI can parse it. Includes tables for tokens, code blocks for CSS, and prose for rules and constraints.

**SKILL.md** — The agent manifest. A short file (under 2KB) that tells an AI assistant: "You are now a designer for this brand. Read README.md first. BRAND_GUIDELINES.md is the source of truth. Here are the 5 most critical constraints to never violate." This is the entry point when the design system is used as a skill/tool.

**colors_and_type.css** — A drop-in CSS file. Contains: all `@font-face` declarations for self-hosted fonts, all CSS custom properties organized by category (colors, gradients, spacing, radii, motion, layout, fonts), and semantic typography rules (h1-h3, body, label, caption, link styles). Any HTML page that links this one file inherits the complete visual foundation. No CDN dependencies.

**preview/*.html** — Individual HTML files, each rendering one design system element as a visual card you can open in a browser. This is the human-readable layer. A designer or stakeholder opens `buttons.html` and sees every button state rendered live. Opens `colors-foundation.html` and sees the actual swatches with hex codes. Each file is self-contained (links to `_card.css` for shared card styling) and loads the design system CSS for accurate rendering.

**[standalone].html** — A single HTML file that combines all preview cards into one browsable page. Heavier to load, but convenient for sharing or reviewing the entire system at a glance.

**ui_kits/** — Production-ready component templates for specific surfaces. A landing page kit might include Hero, Form, ContentSection, and ThankYou components. These are reference implementations that use all the tokens and follow all the rules. The AI can copy-paste and adapt these instead of building from scratch.

---

## The Dual-Layer Approach

This is the core insight that makes this system work: **every rule exists in two forms.**

### Layer A: Machine-readable (Markdown + CSS)

The AI reads `.md` files and `.css` files. These contain:
- Exact hex codes, not "a warm orange"
- Exact pixel values, not "generous spacing"
- Explicit rules with examples, not "use good judgment"
- CSS custom properties it can reference directly in code

**Why markdown:** Every AI can parse markdown. Tables, code blocks, and structured prose translate perfectly into AI understanding. No proprietary format required.

**Why CSS custom properties:** The AI generates HTML/CSS. If every value is a `var(--token)`, the output is automatically consistent. Change a token once, everything updates.

### Layer B: Human-readable (HTML previews)

Humans don't read hex codes and CSS variables. They need to see the thing. The preview HTML files render every element visually so a human can:
- Verify colors look right in context
- Check that type hierarchy feels correct
- See hover/press states in action
- Spot issues before they reach production

**The bridge:** The HTML preview files IMPORT the CSS tokens file. They don't duplicate values. So when the AI updates a token, the preview automatically reflects the change.

### Why both layers matter

Without Layer A: The AI guesses, hallucinates values, drifts off-brand with every output.
Without Layer B: The human can't verify, can't give feedback, can't iterate.
Together: The human sees it, the AI builds it, and they stay in sync.

---

## The SKILL.md file

This small file is the bridge between your design system and any AI that uses it. It's a manifest — under 2KB — that tells the AI three things:

1. **What this is** (a design system for [brand])
2. **Where to look** (README.md first, BRAND_GUIDELINES.md for source of truth)
3. **The 5 non-negotiable constraints** (the rules that, if violated, break the brand)

### Template

```markdown
---
name: [your-brand]-design
description: Use this skill to generate well-branded interfaces and assets for [Brand Name]. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components.
user-invocable: true
---

Read `README.md` first, then use `BRAND_GUIDELINES.md` as the source of truth.
`colors_and_type.css` is a drop-in stylesheet of tokens + semantic type.

If creating visual artifacts, use the components in `ui_kits/` as reference implementations.
If the user invokes this skill without guidance, ask what they want to build.

Key constraints to remember:
1. [Your #1 constraint — e.g., "Dark foundation always. 85/10/4/1 dominance."]
2. [Your #2 constraint — e.g., "Orange is for action only; violet is for structure only."]
3. [Your #3 constraint — e.g., "Accent font on 1-3 keywords per headline, always colored."]
4. [Your #4 constraint — e.g., "Body text never below 16px desktop / 15px mobile."]
5. [Your #5 constraint — e.g., "Italian copy first. Sentence case. No hype."]
```

---

## How to build it: the step-by-step process

### Step 1: Decisions (you)
Read Layers 1-9 above. For each layer, write down your choices. You don't need to design anything — just decide. "My brand is dark and premium. My accent color is this orange. My body font is Satoshi." These are the inputs.

### Step 2: Generate the foundation (AI)
Give the AI your decisions and this document. Ask it to generate:
- `BRAND_GUIDELINES.md` — the full canonical document
- `colors_and_type.css` — the CSS tokens and base styles
- `SKILL.md` — the agent manifest

### Step 3: Generate the previews (AI)
Ask the AI to create each preview HTML file. Review them in your browser. This is where you iterate — "the orange is too bright," "the heading feels too big," "the cards need more padding." Each round of feedback sharpens the system.

### Step 4: Generate the UI kits (AI)
Once the foundation is locked, ask the AI to build reference components for your surfaces — a landing page kit, a slide deck kit, etc. These are the production-ready templates.

### Step 5: Package
Ask the AI to create the README.md (the index) and the standalone HTML (the single-file browser). You now have a complete design system folder that any AI can read to produce on-brand work forever.

### Step 6: Maintain
The design system evolves. When you add a new surface, add a new UI kit. When you refine a color, update the CSS tokens (the previews auto-update). When you learn what works, add it to the brand guidelines.

---

## Quality checklist

Before you call it done, verify:

**Completeness**
- [ ] All 9 layers are documented in BRAND_GUIDELINES.md
- [ ] Every color has a token name, hex value, and defined role
- [ ] Every component has ALL states (rest, hover, focus, active, disabled, loading, error, success where applicable)
- [ ] Breakpoints are defined with explicit values
- [ ] Responsive behavior is documented for type, spacing, and layout
- [ ] Light mode / inverted tokens exist if any surface needs them
- [ ] Content rules include good AND bad examples

**File structure**
- [ ] README.md exists and maps the entire folder
- [ ] SKILL.md exists with the 5 non-negotiable constraints
- [ ] colors_and_type.css contains all tokens and base styles
- [ ] Font files are self-hosted in assets/fonts/
- [ ] Logo variants cover all color/form combinations needed
- [ ] Every preview HTML file renders correctly in browser
- [ ] Standalone HTML compiles the entire system

**AI-readability**
- [ ] No values are described vaguely ("warm," "generous," "subtle") — everything has a number
- [ ] Rules have explicit "do this / never do that" framing
- [ ] CSS code blocks are copy-paste ready
- [ ] The AI can generate a complete on-brand page using only the files in this folder

**Human-readability**
- [ ] Preview HTML files show actual rendered elements, not just code
- [ ] Interactive states (hover, press) can be experienced in the preview
- [ ] A person with no design background can open the previews and understand the brand

---

## Final note

A design system is not a deliverable. It's an operating system. The value isn't in the document — it's in every asset you create after it exists, because every one of those assets is automatically coherent, professional, and on-brand.

Build it once. Use it forever.
