---
name: carousel-build
description: >
  Build an Instagram carousel from an approved brief. Executes Step 2 (content
  architecture with approval gate), Step 3 (image prompts), and Step 4 (HTML build).
  Use when brief.md is ready, or user says "build il carosello", "costruisci",
  "step 2", "content architecture", "procedi con il build", or after carousel-brief
  completes automatically.
metadata:
  version: "1.0.0"
---

# carousel-build

Three-step production engine: content architecture, image prompts, HTML build.

## Working directory

```
04_CONTENT_ENGINE/social_media/instagram/
```

## Prerequisites

Before starting, load:
1. The `brief.md` from the current carousel folder (`carousels/YYYYMMDD_slug/`)
2. The brand's `design_system.json` from `brand/{slug}/`
3. The brand's template HTML from `templates/` (dark or light per the brief)
4. Check for approved reference images at `brand/{slug}/reference/`. If present, read `REFERENCE_LOG.md` to know the approved style and the reference image files. These will be used in Step 3.

## STEP 2: Content Architecture [APPROVAL GATE]

Propose the complete structure. Present it clearly:

```
TITOLO CAROSELLO: [title]

S1 COVER/HOOK
  Headline: [exact text WITH line breaks shown as /]
    → e.g. "Il ROAS ti / sta mentendo."  (line 1: 12 chars ✓, line 2: 12 chars ✓)
  Subhead: [supporting text]
  Tag: [pill text, e.g. "Performance ADV . Marco Riva"]

S2 [TIPO: body-full / body-split / stat / quote / insight]
  Label: [step label, e.g. "METRICA 01"]
  Headline: [exact text WITH / line breaks + char count per line]
    → e.g. "CPA: il vero / costo per / cliente"  (12 | 10 | 7 ✓)
  Body: [body text, max 2-3 sentences]
  Immagine: [si/no + brief description if yes]

S3-S6: same structure, always showing / line breaks with char counts

S7 CTA
  Tipo: [Educational / Freebie]
  Eyebrow: [e.g. "Commenta" or "Ti e piaciuto?"]
  Keyword: [e.g. "GUIDA" or "SALVA"]
  Items: [list of 3 items]

IMPORTANT: Every headline in this architecture MUST show explicit / line breaks with character counts. If any line exceeds the limit for its slide type (see LINE BREAKS table above), break it further before presenting for approval.
```

### Slide type selection

Choose from the available types in the template. Refer to `references/slide-types.md` for the CSS classes and layout rules of each type.

Core types (from Morfeus Arc Dark template):
- **s1**: Cover/Hook (always first)
- **s2**: Body full (solid color background, text only)
- **s3**: Body split (text left 54% + visual right 46%)
- **s4**: Stat/Big number (large number + context)
- **s5**: Quote (Playfair italic, editorial feel)
- **s6**: Insight/Takeaway (headline + card)
- **s7**: CTA (always last)

Mix types for rhythm. Never use the same type for consecutive slides (except s3 splits when needed).

### Copy rules (apply to ALL text)

- No em dash. Replace with colon (:) or period.
- One idea per slide. If two concepts exist, split into two slides.
- Body text: 2-3 sentences max per slide.

### LINE BREAKS: mandatory rule (CRITICAL)

Every headline MUST be manually broken into 2-4 short lines. Never write a headline as a single unbroken line. In the content architecture (Step 2), show line breaks with ` / ` notation. In the HTML (Step 4), convert each ` / ` to `<br>`.

Character limits per line (including spaces), based on font size and container width:

| Slide type | Font size | Container | Max chars/line |
|---|---|---|---|
| S1 Cover headline | 140px | full width (944px usable) | 12 |
| S2 Body Full headline | 96px | full width (944px usable) | 18 |
| S3 Split headline | 82px | 54% col (480px usable) | 11 |
| S4 Big Number | 300px | full width | 4 |
| S5 Quote text | 70px | full width (944px usable) | 20 |
| S6 Insight headline | 104px | full width (944px usable) | 15 |
| S7 CTA word | 210px | full width | 6 |

Example:
```
WRONG:  Headline: Il ROAS ti sta mentendo
RIGHT:  Headline: Il ROAS ti / sta mentendo.

WRONG:  Headline: CPA: il vero costo per cliente
RIGHT:  Headline: CPA: il vero / costo per / cliente
```

Count characters (including spaces) in each line. If a line exceeds the limit, break it further.

Use `&nbsp;` between the last two words of each LINE (not just the headline) to prevent widows.

**GATE: Present the structure and WAIT for explicit approval. Do NOT proceed to Step 3 until the user says ok, approved, or equivalent.**

If the user requests changes, revise and re-present. Loop until approved.

Save approved structure as `content.md` in the carousel folder.

## STEP 3: Image Prompts

For each slide marked with an image in the approved content architecture:

1. Write a **descriptive prompt** (1-2 sentences) of what the image should show. Focus on the scene/concept, not style details.
2. Determine the **image type**: illustration, bar chart, pie chart, timeline, comparison
3. Append the **full_suffix** from the brand's `design_system.json` > `illustrations.full_suffix`

Format each prompt:

```
### S{N} - {image type}

PROMPT: {descriptive scene}

{full_suffix from design_system.json}
```

### Reference images: style anchoring

If `brand/{slug}/reference/` exists and contains approved reference images:

1. **Prepend to every prompt:** "Match the visual style of the attached reference images."
2. **In prompts.md**, note which reference image(s) to attach alongside each prompt:
   - For illustrations: attach `ref_illustration.png`
   - For charts/data viz: attach `ref_chart.png`
   - For the third type: attach the matching reference
3. **In manual mode**, instruct the user: "Quando generi le immagini, allega sempre 1-2 reference dalla cartella `brand/{slug}/reference/` per mantenere la coerenza stilistica."
4. **In API mode**, if the API supports image references, include them in the generation call.

If no reference folder exists, use only the `full_suffix` text. The style will be less anchored, but functional. Suggest the user run `carousel-brand-setup` to create references.

Save all prompts to `prompts.md` in the carousel folder.

### Image generation: mode-dependent behavior

Read `design_system.json` > `image_generation.mode`:

**If mode = "manual":**
Present the prompts and say:
> "Genera queste immagini con GPT Image 2.0 (o altro tool) e caricale in `carousels/YYYYMMDD_slug/images/` con i nomi corrispondenti alla slide (s02.png, s03.png, ecc.). Quando hai caricato tutto, dimmi 'fatto' e procedo con il build HTML."

Wait for confirmation before proceeding to Step 4.

**If mode = "api":**
After the user approves the prompts, generate images via the OpenAI API using the script pattern in `references/image-generation-api.md`. Save each image to the `images/` folder with the correct filename (s02.png, s03.png, etc.).

## STEP 4: Build HTML

### Pre-check

Verify all images exist in `images/`. List them and confirm filenames match the expected slide numbers.

### Build process

1. Read the brand's template HTML file (dark or light as specified in brief)
2. For each slide S1-S7, replace:
   - All text content (headlines, body text, labels, CTA items)
   - Image sources in `<img>` tags or background-image CSS (point to `images/sNN.png`)
   - Any brand-specific elements (tag text, brand handle, etc.)
3. Apply copy rules:
   - No em dash anywhere
   - Convert every `/` line break from the content architecture into `<br>` in the HTML
   - Verify `&nbsp;` between the last two words of each LINE (before each `<br>` and at the end)
   - Check that body text doesn't overflow (keep under 3 sentences per slide)
   - **OVERFLOW CHECK**: for every headline, count characters per line (between `<br>` tags). If any line exceeds the max for that slide type (see LINE BREAKS table), shorten or add another `<br>`
4. For split slides with images, replace the placeholder `.illus-box` content with an `<img>` tag:
   ```html
   <img src="images/s03.png" style="width:100%; height:100%; object-fit:cover; border-radius:20px;" />
   ```
5. Save as `carousel.html` in the carousel folder

### Technical rules (CRITICAL: production-learned)

- **SVG brand mark width**: must be explicit pixels, never `width: auto`. Calculate: `viewBox_width * (target_height / viewBox_height)`.
- **Split layout**: the flex row must be on a wrapper child `.split-row`, never directly on the `.slide` element (which is `position: absolute`).
- **No display:block on .slide**: the export script isolates slides but must NOT override `display`. Slides use `display: flex` for vertical centering.
- **Font sizes minimum**: headline >= 120px, body >= 40px, label >= 28px. If text seems small, increase it.
- **Vertical centering**: all slide content must be vertically centered via `justify-content: center` (or `flex-end` for cover S1 only).
- **Horizontal centering (CRITICAL)**: all slide content must be horizontally centered. Every `.slide` must have `align-items: center` and every text element must have `text-align: center`. The only exception is S3 split slides where the text column is left-aligned (`text-align: left`) but the overall layout is still horizontally balanced via the 54/46 split. Without `align-items: center`, text blocks sit flush-left and long headlines overflow the right edge of the slide.
- **Safe zone (CRITICAL)**: the slide canvas is 1080x1350px (portrait) but ALL text content must stay inside the central 1080x1080px square. This means ~135px of vertical padding top and ~135px bottom are reserved for decorative elements (arcs, brand mark, negative space). No headline, body text, label, or CTA text may enter those bands. In CSS terms: the content wrapper inside each `.slide` should have `padding-top` and `padding-bottom` that keep text within the central square. The slide format is ALWAYS 1080x1350 portrait, never square.
- **Slide format**: always 1080w x 1350h pixels. Never generate square (1080x1080) slides. The export script and template must enforce this ratio.

After saving, tell the user:
> "HTML costruito. Puoi dire 'esporta' per generare i PNG."
