# Image Generation API Reference

Used ONLY when `design_system.json` > `image_generation.mode` = `"api"`.

## Python script pattern

```python
import base64
from openai import OpenAI

def generate_illustration(prompt: str, style_suffix: str, output_path: str, quality: str = "high"):
    """
    Generate a single illustration via OpenAI GPT Image 1.
    
    Args:
        prompt: Descriptive scene (1-2 sentences, no style info)
        style_suffix: The full_suffix from design_system.json > illustrations
        output_path: Absolute path to save the PNG (e.g. /path/images/s03.png)
        quality: "low" ($0.02), "medium" ($0.07), "high" ($0.19)
    """
    client = OpenAI()  # reads OPENAI_API_KEY from env
    full_prompt = f"{prompt}\n\n{style_suffix}"
    response = client.images.generate(
        model="gpt-image-1",
        prompt=full_prompt,
        n=1,
        size="1024x1024",
        quality=quality
    )
    image_bytes = base64.b64decode(response.data[0].b64_json)
    with open(output_path, "wb") as f:
        f.write(image_bytes)
```

## Usage in carousel-build

For each slide with an image:

1. Read the prompt from `prompts.md`
2. Read the `full_suffix` from `design_system.json` > `illustrations.full_suffix`
3. Construct the output path: `carousels/YYYYMMDD_slug/images/sNN.png`
4. Call `generate_illustration()` with absolute paths

## Cost per carousel

Typical carousel: 3-4 images at "high" quality = ~$0.57 to $0.76.

## Prerequisites

- `pip install openai` (with `--break-system-packages` in sandbox)
- `OPENAI_API_KEY` set in environment
- OpenAI organization verification completed (required for image generation)

## Error handling

If the API returns an error:
- Content policy violation: rephrase the prompt to be less specific about people/faces
- Rate limit: wait 30 seconds and retry
- API key missing: fall back to manual mode and inform the user
