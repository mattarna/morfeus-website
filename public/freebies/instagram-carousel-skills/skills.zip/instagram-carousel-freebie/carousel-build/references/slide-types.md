# Slide Types Reference

Available slide types in the Arc Dark template system. Each type has specific CSS classes and layout rules.

## Global layout rules (all slide types)

- **Canvas**: 1080x1350px (portrait). NEVER square.
- **Safe zone**: all text content must stay within the central 1080x1080px square. Top ~135px and bottom ~135px are for decorative elements only (arcs, brand mark, negative space). No text in those bands.
- **Horizontal centering**: every slide uses `align-items: center` + `text-align: center` unless noted otherwise (S3 split uses `text-align: left` in the text column).

## S1: Cover / Hook

**Class:** `.s1`
**Background:** `var(--white)` (light)
**Layout:** flex column, `justify-content: flex-end`, `align-items: center`, `text-align: center`
**Arc:** Large primary-color circle, top-right quadrant visible

Elements:
- `.tag`: pill-shaped label (brand category)
- `.headline`: display font, 140-148px, aggressive sizing. **Max 12 chars/line. Must use `<br>` to break into 2-3 lines.**
- `.subhead`: body font, 36-50px, muted color

Accent spans: `.v` = primary color, `.o` = accent color

## S2: Body Full

**Class:** `.s2`
**Background:** `var(--viola)` (primary color, solid)
**Layout:** flex column, `justify-content: center`, `align-items: center`, `text-align: center`
**Arc:** Ghost white circle left + micro accent circle top-right

Elements:
- `.step`: eyebrow label, uppercase, accent color, 28px
- `.headline`: display font, white, 96px. **Max 18 chars/line. Must use `<br>`.**
- `.body-text`: body font, white 72% opacity, 40px

Accent span: `.acc` = white 38% opacity (de-emphasized word)

## S3: Body Split

**Class:** `.s3`
**Background:** `var(--black)`
**Layout:** flex row (54% text + 46% visual)
**Arc:** Primary color circle in visual column, opacity 18%

CRITICAL: The `.s3` class applies `display: flex; flex-direction: row` directly. The col-text and col-visual are direct children.

Elements (col-text, `text-align: left`):
- `.step`: eyebrow, accent color
- `.headline`: display font, white, 82px. **Max 11 chars/line (col is only 54% width). Must use `<br>`.**
- `.body-text`: body font, white 58% opacity, 38px

Elements (col-visual):
- `.illus-box`: bordered container for illustration placeholder
- Replace with `<img>` tag for actual images

When inserting a real image, replace the entire `.illus-box` div:
```html
<div class="col-visual">
  <div class="arc" style="..."></div>
  <img src="images/s03.png" 
       style="width:calc(100% - 48px); height:900px; object-fit:cover; 
              border-radius:20px; position:relative; z-index:2;" />
</div>
```

## S4: Stat / Big Number

**Class:** `.s4`
**Background:** `var(--black)`
**Layout:** flex column, `justify-content: center`, `align-items: center`, `text-align: center`
**Arc:** Primary ghost circle, top-right, opacity 12%

Elements:
- `.big-number`: display font, 300px, white. **Max 4 chars/line.**
- `.o-rule`: orange horizontal rule, 72px wide
- `.stat-label`: display font 600, 46px, white 90%
- `.stat-body`: body font, 38px, white 42%

Accent spans in big-number: `.o` = accent, `.v` = primary

## S5: Quote

**Class:** `.s5`
**Background:** `var(--white)`
**Layout:** flex column, `justify-content: flex-start`, `align-items: center`, `text-align: center`
**Arc:** Primary circle, bottom-right

Elements:
- `.quote-mark`: Playfair Display 240px, primary color 10% opacity
- `.quote-text`: Playfair Display italic 700, 70px. **Max 20 chars/line. Must use `<br>`.**
- `.o-rule`: accent horizontal rule
- `.quote-source`: body font 500, 32px, muted

## S6: Insight / Takeaway

**Class:** `.s6`
**Background:** `var(--white)`
**Layout:** flex column, `justify-content: center`, `align-items: center`, `text-align: center`
**Arc:** Accent color circle, top-left

Elements:
- `.insight-label`: eyebr