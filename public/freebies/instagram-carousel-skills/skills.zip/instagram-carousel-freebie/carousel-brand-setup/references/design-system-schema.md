# design_system.json Schema Reference

Complete schema with all fields. Every brand must have a fully populated file.

```json
{
  "brand": {
    "name": "Brand Name",
    "slug": "brand-slug",
    "instagram_handle": "@handle",
    "tagline": "One-liner descrittivo",
    "language": "it"
  },
  "colors": {
    "primary": "#HEX",
    "accent": "#HEX",
    "neutral_bg": "#HEX",
    "dark": "#HEX",
    "light": "#HEX",
    "notes": {
      "primary": "Role description",
      "accent": "Role description",
      "neutral_bg": "Role description",
      "dark": "Role description",
      "light": "Role description"
    }
  },
  "fonts": {
    "display": {
      "family": "Font Name",
      "weight_headline": 700,
      "weight_sub": 600,
      "google_fonts_param": "family=Font+Name:wght@400;500;600;700"
    },
    "body": {
      "family": "Font Name",
      "weight_regular": 400,
      "weight_medium": 500,
      "weight_bold": 700,
      "google_fonts_param": "family=Font+Name:wght@400;500;700"
    },
    "editorial": {
      "family": "Font Name",
      "style": "italic",
      "weight_regular": 400,
      "weight_bold": 700,
      "google_fonts_param": "family=Font+Name:ital,wght@1,400;1,700"
    }
  },
  "signature": {
    "type": "arc | grid | band | geometric | none",
    "description": "Human-readable description of the structural signature",
    "css_element": "CSS snippet if applicable",
    "notes": "How to use across slides"
  },
  "brand_mark": {
    "type": "svg_inline | text",
    "text_fallback": "Brand Name",
    "svg_height_px": 24,
    "svg_width_px": 186,
    "position": "bottom-right",
    "bottom_px": 56,
    "right_px": 68,
    "z_index": 20,
    "notes": "width esplicita obbligatoria per headless Chromium"
  },
  "templates": {
    "dark": {
      "file": "templates/{slug}/template_dark.html",
      "description": "Dark variant description",
      "when_to_use": "Default usage rule"
    },
    "light": {
      "file": "templates/{slug}/template_light.html",
      "description": "Light variant description",
      "when_to_use": "When to use instead of dark"
    }
  },
  "image_generation": {
    "mode": "manual",
    "notes": "Set to manual. To activate API: change mode to 'api' and set OPENAI_API_KEY in env.",
    "api_provider": "openai",
    "api_model": "gpt-image-1",
    "api_key_env_var": "OPENAI_API_KEY"
  },
  "illustrations": {
    "style": "style description",
    "bg_color": "#HEX",
    "primary_color": "#HEX",
    "accent_color": "#HEX",
    "format": "square 1:1",
    "preferred_tool": "gpt-image-1",
    "full_suffix": "Complete prompt suffix with all style directives. No text in image. Square format 1:1.",
    "types": ["illustration", "bar chart", "pie chart", "timeline", "comparison"],
    "reference_images": {
      "folder": "brand/{slug}/reference/",
      "approved": true,
      "approved_date": "YYYY-MM-DD",
      "files": ["ref_illustration.png", "ref_chart.png", "ref_03.png"],
      "style_notes": "Any adjustments noted during approval (e.g. thicker lines, less background detail)"
    }
  },
  "carousel": {
    "slide_count": 7,
    "category_default": "educational",
    "freebie_trigger_word": "GUIDA",
    "cta_educational": "Salva . Condividi . Seguimi",
    "cta_freebie_template": "Commenta [PAROLA] e ricevi: [LISTA]"
  },
  "copy_rules": [
    "Niente em dash: mai. Usare due punti (:) o punto fermo.",
    "Una idea per slide: mai due concetti sulla stessa slide",
    "Contenuto centrato verticalmente (justify-content) e orizzontalmente (align-items: center + text-align: center) in ogni slide. Eccezione: S3 split ha text-align: left nella colonna testo.",
    "Nessuna widow: usare &nbsp; tra le ultime due parole di OGNI riga (prima di ogni <br> e a fine headline)",
    "Se la slide sembra vuota, il testo e troppo piccolo: aumentare",
    "OGNI headline deve essere spezzato in 2-4 righe con <br>. Mai una riga sola. Limiti chars/riga: S1=12, S2=18, S3=11, S4=4, S5=20, S6=15, S7=6",
    "Formato slide: sempre 1080x1350 portrait, MAI quadrato. Il testo deve stare nel quadrato centrale 1080x1080. I primi ~135px e gli ultimi ~135px sono zona decorativa (archi, brand mark, spazio negativo)."
  ],
  "font_sizes_validated": {
    "headline_cover": 140,
    "headline_split": 82,
    "headline_cta": 152,
    "headline_easter_egg": 100,
    "subheadline_body": 42,
    "subhead_cover": 50,
    "sub_cta": 46,
    "eyebrow_label": 30,
    "notes": "Default values. Validate on first real export and adjust."
  },