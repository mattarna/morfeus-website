# Font Discovery: Personality-to-Font Mapping

When the user doesn't have existing fonts, suggest a trio from Google Fonts based on the brand personality they described.

## Mapping Table

| Personality | Display (headline) | Body (text) | Editorial accent |
|---|---|---|---|
| professionale/tech | Space Grotesk 700 | DM Sans 400/500 | Playfair Display Italic |
| energetico/bold | Syne 700/800 | Plus Jakarta Sans 400/500 | none |
| editoriale/lusso | Cormorant 600/700 | Lato 400 | Cormorant Italic 400 |
| caldo/umano | Nunito 700 | Source Sans 3 400/500 | Lora Italic 400 |
| minimal/clean | Inter 600/700 | Inter 400 | none |

## Google Fonts URL construction

Build the `google_fonts_param` for each font role:

```
family=Space+Grotesk:wght@400;500;600;700
family=DM+Sans:ital,opsz,wght@0,9..40,400;0,9..40,500;0,9..40,700;1,9..40,400
family=Playfair+Display:ital,wght@1,400;1,700
```

The full URL is:
```
https://fonts.googleapis.com/css2?{param1}&{param2}&{param3}&display=swap
```

## Rules

- Always 3 fonts max (display + body + optional editorial)
- If no editorial accent is needed, omit the field entirely from the design system
- All fonts must load from Google Fonts CDN
- Test that the google_fonts_param string is syntactically valid
- Prefer fonts with a wide weight range (400-700 minimum)
