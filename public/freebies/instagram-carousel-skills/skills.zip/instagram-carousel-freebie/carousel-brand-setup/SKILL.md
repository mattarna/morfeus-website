---
name: carousel-brand-setup
description: >
  Set up a new brand for Instagram carousel production. Use when the user says
  "voglio creare i miei caroselli", "setup brand", "sono un nuovo brand",
  "parti da zero", "nuovo brand per Instagram", "configura il brand", or when
  starting the carousel system for the first time with a brand that has no
  design_system.json yet.
metadata:
  version: "1.0.0"
---

# carousel-brand-setup

One-time onboarding that takes a brand from zero to a complete design system, ready for carousel production.

## Before starting

Read the workspace structure. The carousel system lives at:
```
04_CONTENT_ENGINE/social_media/instagram/
```

Check if `brand/` subdirectories already exist. If the user's brand already has a `design_system.json`, inform them and ask if they want to update it or start fresh.

## Flow: detect mode

Ask the user:
> "Hai gia dei documenti del brand (guidelines, palette, font, logo)? Se si, caricali. Altrimenti partiamo da zero con un'intervista."

**Mode A** (documents exist): extract values from uploaded material, fill gaps with targeted questions, skip to OUTPUT.

**Mode B** (from scratch): run the full interview below.

## Interview: Mode B

### Phase 1: Brand identity (5 questions)

Ask these one at a time using AskUserQuestion. Do NOT batch them.

1. "Come si chiama il brand? Descrivi in una riga cosa fa."
2. "Che personalita vuoi comunicare?" Options: professionale/tech, energetico/bold, editoriale/lusso, caldo/umano, minimal/clean
3. "Hai gia dei colori del brand? Se si, dammi i codici HEX. Se no, scegli 2 aggettivi che descrivono il colore del tuo brand."
4. "Hai gia dei font? Se si, dimmi i nomi. Se no, scegli tra: serif classico, sans-serif moderno, sans-serif geometrico, display bold."
5. "Carica il logo se ce l'hai (SVG preferito, PNG accettato). Altrimenti dimmi come si scrive il nome del brand: verra usato come wordmark testuale."

### Phase 2: Visual system (3 questions)

6. "Hai uno stile illustrativo preferito?" Options: fotografico, illustrazione vettoriale, sketch a mano, grafico/data, nessuna illustrazione
7. "Template scuro o chiaro come default? (scuro = piu impatto nel feed, chiaro = piu leggibile/editoriale)"
8. "Hai un elemento geometrico che vuoi usare come firma visiva ricorrente?" Options: cerchio, linea, banda colorata, griglia, nessuno

### Phase 3: Image generation mode

This question is MANDATORY. Always ask it:

> "Vuoi collegare l'API OpenAI per generare le illustrazioni automaticamente con GPT Image 2.0? Se si, ti servira una API key OpenAI. Se no, le generi tu e le carichi manualmente."

Save the answer as `mode: "api"` or `mode: "manual"` in the `image_generation` field of design_system.json.

### Phase 4: Generate proposal

Based on answers, generate:

1. **Complete palette** (primary + accent + neutral_bg + dark + light) with HEX codes
2. **Font trio** from Google Fonts. Use the personality-based selection from `references/font-discovery.md`
3. **Structural signature** proposal with visual description
4. **Illustration style suffix** for AI image prompts

Present the proposal in a readable format. Include actual color swatches if possible.

**GATE: wait for explicit approval before proceeding to style validation.**

### Phase 5: Style validation with reference images

This phase LOCKS the visual style of the brand. Without approved reference images, future carousel prompts have no anchor and the style drifts.

**Goal:** generate 3 test illustrations, get approval, save as permanent reference.

#### 5a. Generate 3 test prompts

Create 3 prompts that cover different illustration types the brand will use most:

1. **Illustration** (conceptual scene): pick a generic business/tech concept relevant to the brand (e.g., "A person building something with blocks" or "Two paths diverging in a landscape")
2. **Bar chart** or **Comparison**: pick a generic data visualization scenario
3. **Free choice**: pick the type most likely to appear in the brand's content (timeline, pie chart, or another illustration)

Each prompt uses:
- A simple, neutral subject (nothing tied to a specific carousel topic)
- The `full_suffix` generated in Phase 4

#### 5b. Generate or request images

**If `image_generation.mode = "api"`:**
Generate all 3 images automatically via the OpenAI API. Save them temporarily to `brand/{slug}/reference/test_01.png`, `test_02.png`, `test_03.png`.

Present them to the user and ask:
> "Queste 3 immagini definiscono lo stile visivo del tuo brand per tutti i caroselli futuri. Ti piacciono? Se vuoi aggiustare qualcosa (piu dettaglio, meno colore, diverso tratto) dimmelo: rigenero con il prompt aggiornato."

**If `image_generation.mode = "manual"`:**
Present the 3 prompts and say:
> "Genera queste 3 immagini con GPT Image 2.0 (o il tool che preferisci) e caricale qui. Queste diventeranno le reference permanenti del tuo stile: ogni futuro carosello partira da questo standard."

Wait for the user to upload the 3 images.

#### 5c. Iterate until approved

If the user asks for changes:
- Adjust the `full_suffix` (style description) based on the feedback
- Regenerate (api mode) or ask the user to regenerate (manual mode)
- Loop until the user says the style is right

**GATE: explicit approval required.** The user must confirm: "ok, questo e lo stile."

#### 5d. Save approved references

1. Create the permanent reference folder: `brand/{slug}/reference/`
2. Save the 3 approved images as:
   - `brand/{slug}/reference/ref_illustration.png`
   - `brand/{slug}/reference/ref_chart.png`
   - `brand/{slug}/reference/ref_03.png` (named by type)
3. Create `brand/{slug}/reference/REFERENCE_LOG.md`:

```markdown
---
brand: {slug}
approved_date: YYYY-MM-DD
images_count: 3
---

# Reference Images: {Brand Name}

These images define the approved visual style for all carousel illustrations.

## How to use

When