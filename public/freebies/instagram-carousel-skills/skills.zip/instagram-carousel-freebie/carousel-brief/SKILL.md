---
name: carousel-brief
description: >
  Collect the brief for a new Instagram carousel. Use when the user says
  "nuovo carosello", "voglio fare un carosello su X", "brief", "carosello su",
  "prossimo carosello", "facciamo un carosello", or wants to start producing
  a new carousel for any configured brand.
metadata:
  version: "1.0.0"
---

# carousel-brief

Collect raw input, define parameters, and save a structured brief.md that feeds into carousel-build.

## Working directory

All carousel work lives at:
```
04_CONTENT_ENGINE/social_media/instagram/
```

## Flow

### 1. Identify the brand

Check `brand/` subdirectories for existing design systems.

- If only ONE brand exists: use it automatically, confirm with user.
- If MULTIPLE brands exist: ask which brand this carousel is for.
- If NO brand exists: stop and tell the user to run carousel-brand-setup first.

Load the brand's `design_system.json` into context. Note the `image_generation.mode` value for later use by carousel-build.

### 2. Collect raw input

Ask the user to paste or upload their raw material:
> "Incolla il testo grezzo: note, appunti, link, trascrizione audio. Parto da qui per costruire il carosello."

Accept any format: bullet points, stream of consciousness, links, pasted articles, voice transcription.

### 3. Ask parameters (MANDATORY questions)

These questions are MANDATORY. Never skip or assume the answers.

**a. Category:**
> "Questo carosello e Educational o Freebie?"
> - Educational: S7 = "Salva . Condividi . Seguimi"
> - Freebie: S7 = "Commenta [PAROLA]" + lista di cosa ricevono

NEVER assume the category. Always ask explicitly. This is a hard rule from the user's feedback.

**b. If Freebie:**
> "Quale parola chiave per la CTA? (es. GUIDA, TOOL, PROMPT, CHECKLIST)"
> "Cosa ricevono? (max 3 item)"

**c. Slides with images:**
> "Quante slide body (S2-S6) hanno un'immagine? Di default ne suggerisco 3-4."

**d. Template:**
> "Template Arc Dark (default) o Arc Light? (Arc Light solo se >=3 illustrazioni con sfondo crema)"

Default to Arc Dark unless the user explicitly chooses Light.

**e. Notes:**
> "Ci sono vincoli, tono specifico, angoli da evitare, audience specifica?"

### 4. Create carousel folder

Generate the folder name: `YYYYMMDD_topic-slug` where:
- YYYYMMDD is today's date
- topic-slug is a 2-4 word kebab-case slug derived from the topic

Create the folder at: `carousels/YYYYMMDD_topic-slug/`

Create subfolders: `images/`, `slides/`

### 5. Save brief.md

Write `brief.md` in the carousel folder using this structure:

```markdown
---
carousel_id: YYYYMMDD_topic-slug
date: YYYY-MM-DD
brand: {brand-slug}
status: brief
---

# BRIEF: [TITOLO PROVVISORIO]

## INPUT GREZZO

[raw text from user]

## PARAMETRI

**Topic / Angle:** [distilled topic]
**Categoria:** [Educational | Freebie]
**CTA keyword:** [only if Freebie]
**Cosa ricevono:** [only if Freebie, max 3 items]
**Template:** [Arc Dark | Arc Light]
**Slide con immagine:** [list, e.g. S3, S4, S5]

## NOTE AGGIUNTIVE

[any constraints or notes]
```

### 6. Auto-launch carousel-build

After saving the brief, immediately proceed to carousel-build Step 2 (Content Architecture). Do not wait for the user to invoke a separate skill. Say:

> "Brief salvato. Procedo con la content architecture (Step 2)."

Then execute the carousel-build skill starting from Step 2.

## Rules

- ALWAYS ask category (Educational vs Freebie). Never assume. This is the #1 rule.
- No em dash in any text you write
- The slug must be lowercase with hyphens, no spaces or special chars
- If the raw input is thin (< 3 sentences), ask the user for more context before proceeding
