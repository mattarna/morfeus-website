---
name: carousel-feedback
description: >
  Collect qualitative feedback after a carousel is exported and reviewed.
  Use when the user says "feedback", "cosa non mi e piaciuto", "rivedi il sistema",
  "aggiorna il design system", or after carousel-export is approved and the user
  wants to log what worked and what didn't.
metadata:
  version: "1.0.0"
---

# carousel-feedback

Capture per-carousel feedback and propagate systemic changes to the brand's design system and living doc.

## Working directory

```
04_CONTENT_ENGINE/social_media/instagram/
```

## Flow

### 1. Identify the carousel

If not obvious from context, ask which carousel the feedback is for. List recent carousels in `carousels/`.

Load the brand's `design_system.json` to know the current state.

### 2. Ask 3 questions

Ask these one at a time:

**Q1:**
> "Cosa non ha funzionato? (copy, visual, layout, struttura, font sizes, immagini)"

**Q2:**
> "Cosa ha funzionato bene e vuoi ripetere?"

**Q3:**
> "C'e qualcosa che cambieresti nel sistema? (template, workflow, regole, design system)"

### 3. Save feedback.md

Write `feedback.md` in the carousel folder:

```markdown
---
carousel: YYYYMMDD_slug
date: YYYY-MM-DD
brand: {brand-slug}
carousel_count: {N from design_system.json meta.carousel_count + 1}
---

# Feedback: [Titolo Carosello]

## Cosa non ha funzionato
{Q1 answer}

## Cosa ha funzionato e va ripetuto
{Q2 answer}

## Modifiche al sistema
{Q3 answer, or "Nessuna modifica necessaria"}

## Note per prossimo carosello
{any derived insights}
```

### 4. Propagate systemic changes

If Q3 implies a change to the system, execute it:

**Copy rules change** (e.g., "il copy era troppo lungo"):
- Update `copy_rules` array in `design_system.json`
- Add entry to the living doc's LOG DECISIONI

**Font size change** (e.g., "il testo era troppo piccolo su mobile"):
- Update `font_sizes_validated` in `design_system.json`
- Add entry to LOG DECISIONI

**Template change** (e.g., "l'arco copriva il testo"):
- Note the change needed but do NOT auto-edit the HTML template
- Add a TODO to the living doc's OPEN ISSUES
- Tell the user: "Questa modifica richiede un intervento manuale sul template HTML."

**Workflow change** (e.g., "voglio approvare anche i prompt prima del build"):
- Update the living doc's workflow section
- Add entry to LOG DECISIONI

If no systemic changes: skip this step.

### 5. Update carousel count

Increment `meta.carousel_count` in `design_system.json`.

If this is the first carousel (`carousel_count` was 0):
- Set `meta.validated` to `true`
- Set `meta.first_carousel_date` to today's date
- Set `meta.first_carousel_slug` to this carousel's slug

### 6. Periodic system review (every 5 carousels)

If `carousel_count` is a multiple of 5, trigger a system review:

1. Read ALL `feedback.md` files from the last 5 carousels
2. Identify recurring patterns (e.g., "3 times the user said copy was too long")
3. Propose systemic updates to the design system
4. Present proposals and wait for approval before applying

Say:
> "Hai completato {N} caroselli. Ho analizzato i feedback recenti. Ecco le ottimizzazioni che suggerisco al sistema: [proposals]"

### 7. Confirm and close

> "Feedback salvato. Il design system e stato aggiornato. carousel_count: {N}."

If the periodic review happened, also summarize what was changed.

## Rules

- Never auto-apply changes to the template HTML. Always flag these as manual TODOs.
- The feedback.md format is fixed. Don't restructure it.
- LOG DECISIONI entries use the format: `| YYYY-MM-DD | Decision | Motivation |`
- No em dash anywhere in the feedback file
