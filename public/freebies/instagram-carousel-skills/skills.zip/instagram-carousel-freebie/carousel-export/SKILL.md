---
name: carousel-export
description: >
  Export an Instagram carousel HTML to individual PNG slides. Use when the user
  says "esporta", "export", "genera i PNG", "screenshot", "esporta le slide",
  or after carousel-build completes Step 4 and the user is ready to export.
metadata:
  version: "1.0.0"
---

# carousel-export

Run the Playwright export script to generate 7 PNG files at 1080x1350px from the carousel HTML.

## Working directory

```
04_CONTENT_ENGINE/social_media/instagram/
```

## Flow

### 1. Identify the carousel

If not obvious from context, ask:
> "Quale carosello vuoi esportare?"

List available carousels in `carousels/` that have a `carousel.html` file.

### 2. Verify prerequisites

Check that:
- `carousel.html` exists in the carousel folder
- The `images/` folder contains the expected image files (if the carousel uses images)
- The export script exists at `export_carousel.py`

If `carousel.html` doesn't exist, tell the user to complete carousel-build first.

### 3. Build ABSOLUTE paths

**CRITICAL: export_carousel.py requires absolute paths. Relative paths cause `net::ERR_INVALID_URL`.**

Construct the full absolute paths on the VM filesystem. The workspace mount path changes per session, so detect it dynamically:

```bash
# Find the current session mount path
WORKSPACE=$(find /sessions -maxdepth 3 -name "MORFEUS BIZ" -type d 2>/dev/null | head -1)
```

Then build absolute paths:
```
HTML_PATH = {WORKSPACE}/04_CONTENT_ENGINE/social_media/instagram/carousels/YYYYMMDD_slug/carousel.html
OUTPUT_DIR = {WORKSPACE}/04_CONTENT_ENGINE/social_media/instagram/carousels/YYYYMMDD_slug/slides/
```

Create the output directory if it doesn't exist:
```bash
mkdir -p "{OUTPUT_DIR}"
```

### 4. Install dependencies (if needed)

Check if Playwright is available. If not:
```bash
pip install playwright --break-system-packages
playwright install chromium
```

### 5. Run the export

```bash
cd "{WORKSPACE}/04_CONTENT_ENGINE/social_media/instagram"
python3 export_carousel.py "{HTML_PATH}" "{OUTPUT_DIR}"
```

### 6. Verify output

Check that `s01.png` through `s07.png` exist in the `slides/` folder:
```bash
ls -la "{OUTPUT_DIR}"
```

If any file is missing, report which slides failed and suggest re-running.

### 7. Present for review

Tell the user:
> "Export completato: 7 slide PNG a 1080x1350px in `slides/`."

List all generated files with their paths so the user can open and review them visually.

Then ask:
> "Vuoi procedere con il feedback (carousel-feedback)?"

## Technical notes (CRITICAL)

These are production-learned fixes. Never skip them.

1. **PATH ASSOLUTI**: the script uses `file://` URLs for Playwright. Relative paths = `ERR_INVALID_URL`. Always use the full absolute path from root.

2. **BRAND MARK SVG**: the export script injects the SVG logo via `page.evaluate()` because headless Chromium on `file://` doesn't execute inline `<script>` tags. This is handled automatically by the script's `BRAND_MARK_JS`.

3. **ISOLATE_JS**: the script that isolates each slide for screenshot does NOT set `display: block` on the `.slide` element. This is correct and intentional. Setting `display: block` would break flex layouts and vertical centering.

4. **SVG width**: if the brand mark appears clipped or oversized in the export, the SVG width is not set explicitly. Fix in the HTML: set `width: Npx` calculated as `viewBox_width * (target_height / viewBox_height)`.

## Troubleshooting

- **Blank slides**: images might not have loaded. Check that image paths in `carousel.html` are relative to the HTML file location (`images/s03.png`, not absolute paths).
- **Text not centered vertically**: the ISOLATE_JS must not override `display` on `.slide`. Check that the export script matches the version in the repo.
- **Text overflows right or sits flush-left**: the `.slide` is missing `align-items: center` or text elements are missing `text-align: center`. Check the carousel HTML against the rules in slide-types.md.
- **Font not rendering**: Google Fonts require network access during export. Playwright loads them via the `<link>` tag in the HTML. If fonts fail, the slides will render in fallback sans-serif.
