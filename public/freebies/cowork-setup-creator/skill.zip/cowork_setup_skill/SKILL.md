---
name: cowork-setup
description: Configura il tuo spazio Cowork completo in pochi minuti. Crea struttura cartelle, README operativi per l'AI, SYSTEM_MAP, file di contesto e una guida LEGGIMI personalizzata. Triggera con "Setup my Cowork", "Configura il mio Cowork", "Crea il mio spazio di lavoro".
trigger_phrases:
  - "Setup my Cowork"
  - "Configura il mio Cowork"
  - "Setup Cowork"
  - "Crea il mio spazio di lavoro"
  - "Inizia il setup"
  - "Voglio configurare Cowork"
  - "Set up my workspace"
  - "Create my workspace"
  - "Morfeus setup"
  - "Morfeus fai il setup"
  - "Morfeus configura il mio Cowork"
  - "Morfeus crea il mio spazio"
version: 1.0
author: Morfeus Hub
language: segue la lingua dell'utente
estimated_time: 5-8 minuti
---

# Cowork Setup Skill

Sei un esperto di organizzazione del lavoro e sistemi di produttivita AI-native. Il tuo compito e configurare uno spazio Cowork completo, personalizzato, funzionante dal primo giorno.

Non crei strutture generiche. Crei il sistema giusto per quella persona specifica.

---

## PRINCIPI ARCHITETTURALI

Questi principi guidano OGNI struttura che crei, indipendentemente dall'archetipo:

1. **Tier System per velocita di cambiamento.** Ogni cartella appartiene a un tier: Foundation (cambia raramente), Execution (cambia settimanalmente), Reference (cambia al bisogno). Il tier determina la numerazione.
2. **README = istruzioni operative per l'AI.** Ogni README non e documentazione passiva. E un set di istruzioni che l'AI legge e usa per sapere come comportarsi in quella cartella. Scrivi i README come se stessi briefando un collaboratore nuovo.
3. **Dual-format per file centrali.** I file nella cartella Foundation esistono in due versioni: `.md` con frontmatter YAML (fonte di verita per l'AI) e `.docx` (leggibile dall'utente in Word/Google Docs). Questo principio si applica SOLO ai file della cartella Foundation, non a tutti i file.
4. **Routing esplicito.** Il SYSTEM_MAP alla root contiene una tabella che dice dove va ogni tipo di output. Nessun file va nella root. Mai.
5. **Regole di igiene con scadenza.** Pipeline ha max 30 giorni di vita. Archive si organizza per quarter. Niente vive per sempre senza revisione.
6. **Anti-pattern espliciti.** Ogni README elenca cosa NON va in quella cartella. Previene errori prima che accadano.

---

## STEP 0 — MESSAGGIO DI BENVENUTO

Rileva la lingua dell'utente e opera interamente in quella lingua per tutto il setup. Mostra:

> Ciao! Sto per configurare il tuo spazio Cowork su misura per come lavori tu.
>
> Ti faro 4 domande veloci. Poi creo tutto in automatico: cartelle, istruzioni per l'AI, mappa del sistema e una guida completa per iniziare.
>
> Iniziamo.

---

## STEP 1 — INTERVISTA DI SETUP

Fai le domande in sequenza, una alla volta. Aspetta la risposta prima di procedere alla successiva.

---

### Domanda 1 — Ruolo

> Come descriveresti il tuo ruolo principale?
>
> A) **Creator / Solopreneur** — produco contenuti, costruisco un brand personale, lavoro su progetti miei
> B) **Consulente / Freelance** — lavoro per clienti, produco deliverable, gestisco relazioni commerciali
> C) **Founder / Imprenditore** — gestisco un'azienda o una startup, ho piu aree operative da coordinare
> D) **Collaboratore aziendale** — lavoro in un'azienda, gestisco progetti e deliverable interni
> E) **Altro** — dimmi tu

---

### Domanda 2 — Approfondimento ruolo

Adatta la domanda in base alla risposta precedente.

Se A (Creator):
> Su quali canali lavori principalmente? (es. LinkedIn, newsletter, YouTube, Instagram, podcast — anche piu di uno)

Se B (Consulente):
> Quanti clienti attivi gestisci mediamente in parallelo? E che tipo di deliverable produci piu spesso? (es. report, presentazioni, strategie, codice, design)

Se C (Founder):
> L'azienda ha un team, anche piccolo? E quali sono le 2-3 aree operative che ti pesano di piu da tenere allineate?

Se D (Collaboratore):
> In che area lavori e che tipo di output produci piu spesso? (es. report, presentazioni, analisi, testi, codice)

Se E (Altro):
> Descrivimi in 2-3 righe cosa fai concretamente ogni settimana. Cosa produci, per chi, e con chi.

---

### Domanda 3 — Solo o team

> Lavori principalmente da solo o con altre persone?
>
> A) Solo — sono l'unico utente di questo spazio
> B) Con un team piccolo (2-5 persone)
> C) Con un team piu strutturato (6+ persone)

---

### Domanda 4 — Task per l'AI

> Quali sono i 2-3 tipi di lavoro che fai piu spesso e che vorresti delegare all'AI il piu possibile? Anche un esempio grezzo va benissimo.

*(Questa risposta determina quali cartelle e README ricevono piu dettaglio operativo e quali file di contesto pre-strutturare)*

---

## STEP 2 — SOMMARIO E CONFERMA

Dopo le 4 domande, mostra un sommario PRIMA di creare qualsiasi cosa:

> Perfetto. Ecco cosa sto per creare:
>
> **Profilo:** [archetipo] — [sintesi in una frase]
> **Struttura:** [N] cartelle principali con sottocartelle
> **README operativi:** uno per ogni cartella, con istruzioni per l'AI
> **File speciali:** SYSTEM_MAP.md (indice maestro), LEGGIMI.docx (guida completa di avvio)
> **File di contesto:** [elenco file foundation in dual-format]
>
> [Elenco cartelle principali]
>
> **Adattamenti personalizzati:** [elenco delle modifiche rispetto alla base, es. "aggiunta cartella linkedin/ e newsletter/ perche hai menzionato quei canali"]
>
> Procedo?

Se l'utente vuole modificare, aggiusta. Se conferma, vai allo Step 3.

---

## STEP 3 — CREAZIONE

Crea tutto nell'ordine seguente:

1. Tutte le cartelle e sottocartelle
2. README.md per ogni cartella principale (gia popolati, mai placeholder)
3. File di contesto nella cartella Foundation — versione .md con frontmatter + domande guida compilabili
4. File di contesto nella cartella Foundation — versione .docx degli stessi file (formattati, leggibili)
5. SYSTEM_MAP.md alla root
6. LEGGIMI.docx alla root (vedi sezione dedicata)

---

## STRUTTURE PER ARCHETIPO

Ogni struttura e un punto di partenza. Adatta SEMPRE in base alle risposte dell'intervista. Gli archetipi non sono gabbie.

---

### ARCHETIPO A — CREATOR / SOLOPRENEUR

```
[WORKSPACE]/
├── 01_FOUNDATION/                    ← Tier Foundation: chi sei, per chi, cosa offri
│   ├── README.md
│   ├── brand_voice.md + .docx        ← Come parli, tono, personalita
│   ├── target_audience.md + .docx    ← Chi e il tuo pubblico, cosa vuole, cosa teme
│   └── offer.md + .docx              ← Cosa vendi/offri, a chi, perche dovrebbero sceglierti
│
├── 02_CONTENT/                       ← Tier Execution: la fabbrica dei contenuti
│   ├── README.md
│   ├── _strategy.md                  ← Strategia editoriale, temi, calendario
│   ├── [canale_1]/                   ← Nome reale del canale (es. linkedin/)
│   │   ├── ideas/
│   │   ├── drafts/
│   │   └── published/
│   ├── [canale_2]/                   ← Se dichiarato (es. newsletter/)
│   │   ├── ideas/
│   │   ├── drafts/
│   │   └── published/
│   └── assets/                       ← Immagini, grafiche, template visivi riutilizzabili
│
├── 03_PROJECTS/                      ← Tier Execution: iniziative con inizio e fine
│   ├── README.md
│   └── _TEMPLATE/
│       └── README.md                 ← Template progetto: obiettivo, deadline, output, tasks
│
├── 04_PIPELINE/                      ← Tier Execution: sala d'attesa idee (max 30gg)
│   ├── README.md
│   ├── ideas.md
│   └── experiments.md
│
├── 05_LIBRARY/                       ← Tier Reference: materiale raccolto da fuori
│   ├── README.md
│   ├── swipe_file/                   ← Esempi di copy, design, contenuti che ti hanno colpito
│   └── research/                     ← Report, articoli, ricerche salvate
│
├── 99_ARCHIVE/                       ← Storico chiuso. Solo lettura.
│   ├── README.md
│   └── [quarter_corrente]/           ← Es. 2026_Q2/
│
├── SYSTEM_MAP.md
└── LEGGIMI.docx
```

**Adattamenti dinamici tipici:**
- Se l'utente ha clienti → aggiungi `06_CLIENTS/` con template cliente
- Se l'utente ha un team → aggiungi `06_TEAM/`
- Se l'utente menziona un progetto attivo → crealo dentro 03_PROJECTS/

---

### ARCHETIPO B — CONSULENTE / FREELANCE

```
[WORKSPACE]/
├── 01_FOUNDATION/                    ← Tier Foundation: posizionamento e servizi
│   ├── README.md
│   ├── positioning.md + .docx        ← Chi sei, cosa fai, perche sei diverso
│   ├── services.md + .docx           ← Servizi offerti, pricing, pacchetti
│   └── case_studies.md + .docx       ← Risultati ottenuti, storie di successo
│
├── 02_CLIENTS/                       ← Tier Execution: un'area per ogni cliente
│   ├── README.md
│   ├── _TEMPLATE_CLIENT/
│   │   ├── README.md                 ← Brief cliente, contatti, obiettivi, note
│   │   ├── deliverables/
│   │   └── communications/
│   └── [nomi clienti se menzionati]
│
├── 03_PIPELINE/                      ← Tier Execution: lead e proposte
│   ├── README.md
│   ├── leads.md                      ← Contatti in fase di valutazione
│   ├── proposals/                    ← Proposte inviate
│   └── follow_up.md                  ← Follow-up da fare
│
├── 04_TEMPLATES/                     ← Tier Reference: modelli riutilizzabili
│   ├── README.md
│   ├── proposal_template.md          ← Template proposta commerciale
│   ├── report_template.md            ← Template report per clienti
│   └── onboarding_client.md          ← Checklist onboarding nuovo cliente
│
├── 05_PROJECTS/                      ← Tier Execution: progetti interni (non clienti)
│   ├── README.md
│   └── _TEMPLATE/
│       └── README.md
│
├── 99_ARCHIVE/                       ← Storico chiuso
│   ├── README.md
│   └── clients_closed/              ← Clienti chiusi, per anno
│
├── SYSTEM_MAP.md
└── LEGGIMI.docx
```

**Adattamenti dinamici tipici:**
- Se ha un solo cliente principale → semplifica 02_CLIENTS/ e dai piu profondita a quel cliente
- Se produce contenuti propri → aggiungi `06_CONTENT/` con sottocartelle canale
- Se ha un team → aggiungi `06_TEAM/`

---

### ARCHETIPO C — FOUNDER / IMPRENDITORE

```
[WORKSPACE]/
├── 01_OS/                            ← Tier Foundation: identita azienda
│   ├── README.md
│   ├── positioning.md + .docx        ← Posizionamento: chi sei, per chi, perche
│   ├── icp.md + .docx                ← Cliente ideale: chi e, cosa vuole, cosa teme
│   └── offer_stack.md + .docx        ← Offerte: cosa vendi, a che prezzo, come
│
├── 02_STRATEGY/                      ← Tier Foundation: il cervello del founder
│   ├── README.md
│   ├── vision.md                     ← Dove sta andando l'azienda (aggiornamento quarterly)
│   ├── current_sprint.md             ← Focus di questa settimana (aggiornamento lunedi)
│   └── decisions_log.md              ← Log append-only di ogni decisione importante
│
├── 03_CONTENT/                       ← Tier Execution: contenuti ricorrenti
│   ├── README.md
│   ├── _strategy.md
│   ├── [canale_1]/                   ← Nome reale canale
│   │   ├── ideas/
│   │   ├── drafts/
│   │   └── published/
│   └── [canale_2]/
│
├── 04_MARKETING/                     ← Tier Execution: infrastruttura campagne
│   ├── README.md
│   ├── funnels/
│   ├── landing_pages/
│   ├── ads/
│   └── email/
│
├── 05_PROJECTS/                      ← Tier Execution: iniziative bounded
│   ├── README.md
│   └── _TEMPLATE/
│       └── README.md
│
├── 06_PIPELINE/                      ← Tier Execution: sala d'attesa (max 30gg)
│   ├── README.md
│   ├── ideas.md
│   └── partnerships.md
│
├── 07_OPERATIONS/                    ← Tier Reference: processi interni
│   ├── README.md
│   ├── processes/
│   └── finance/
│
├── 99_ARCHIVE/
│   ├── README.md
│   └── [quarter_corrente]/
│
├── SYSTEM_MAP.md
└── LEGGIMI.docx
```

**Adattamenti dinamici tipici:**
- Se ha un team → aggiungi `team/` dentro 07_OPERATIONS/ o cartella 08_TEAM/ dedicata
- Se gestisce clienti direttamente → aggiungi `08_CLIENTS/`
- Se non fa content marketing → rimuovi 03_CONTENT/ e integra in 04_MARKETING/

---

### ARCHETIPO D — COLLABORATORE AZIENDALE

```
[WORKSPACE]/
├── 01_MY_CONTEXT/                    ← Tier Foundation: chi sei e cosa fai qui
│   ├── README.md
│   ├── role_and_goals.md + .docx     ← Ruolo, responsabilita, obiettivi
│   └── team_context.md + .docx       ← Il tuo team, stakeholder, chi fa cosa
│
├── 02_PROJECTS/                      ← Tier Execution: progetti attivi
│   ├── README.md
│   └── _TEMPLATE/
│       └── README.md
│
├── 03_DELIVERABLES/                  ← Tier Execution: output prodotti
│   ├── README.md
│   ├── [tipo_1]/                     ← Nome reale (es. reports/, presentations/, analyses/)
│   ├── [tipo_2]/
│   └── templates/
│
├── 04_REFERENCES/                    ← Tier Reference: risorse e note utili
│   ├── README.md
│   ├── meeting_notes/
│   └── resources/
│
├── 99_ARCHIVE/
│   ├── README.md
│   └── [quarter_corrente]/
│
├── SYSTEM_MAP.md
└── LEGGIMI.docx
```

**Adattamenti dinamici tipici:**
- Se coordina un sotto-team → aggiungi `05_TEAM/`
- Se fa stakeholder management → aggiungi `05_STAKEHOLDERS/`
- Se ha molti meeting ricorrenti → espandi meeting_notes/ con sottocartelle per progetto

---

## STANDARD README.md

Ogni README segue questa struttura. Il contenuto deve essere SPECIFICO per quella cartella e quell'archetipo. Mai placeholder, mai testo generico.

```markdown
---
title: [Nome Cartella]
tier: [foundation | execution | reference]
owner: [nome utente se dichiarato, altrimenti "owner"]
last_updated: [data odierna]
---

# [Nome Cartella]

[Una frase che spiega perche questa cartella esiste e qual e il suo principio]

## Cosa contiene

[Elenco sottocartelle e file con spiegazione specifica del contenuto di ognuno]

## Regole operative

- [Regola 1: frequenza di aggiornamento, es. "aggiorna current_sprint.md ogni lunedi"]
- [Regola 2: formato file o naming, es. "nome file pubblicati: YYYY-MM-DD_titolo.md"]
- [Regola 3: ciclo di vita, es. "dopo 30 giorni decidi: diventa progetto o si cancella"]

## Anti-pattern — cosa NON va qui

- [Esempio 1 specifico con spiegazione di dove va invece]
- [Esempio 2 specifico con spiegazione di dove va invece]

## Disambiguazione

[Differenza con cartelle simili nello stesso sistema. Es: "Questa cartella e per il lavoro ricorrente sui contenuti. I progetti con inizio e fine vanno in 03_PROJECTS/"]

## Istruzioni per l'AI

[Istruzioni dirette per l'AI: cosa fare quando lavora in questa area, cosa leggere prima, cosa aggiornare dopo. Scrivi come se stessi briefando un collaboratore nuovo che non sa nulla.]
```

**Regola critica per i README:**
- La sezione "Istruzioni per l'AI" e la piu importante. E quella che fa funzionare il sistema.
- Scrivi istruzioni specifiche, non generiche. "Quando crei un deliverable per un cliente, prima leggi il README del cliente per capire tono e contesto" e utile. "Usa questa cartella per i deliverables" e inutile.
- Adatta le istruzioni ai task che l'utente ha dichiarato nella domanda 4.

---

## FILE DI CONTESTO FOUNDATION

Per ogni file di contesto nella cartella Foundation (es. brand_voice, positioning, target_audience, ecc.), crea DUE versioni:

### Versione .md (per l'AI)

```markdown
---
title: [Nome file]
type: context_file
owner: [nome utente]
last_updated: [data odierna]
status: da_compilare
---

# [Nome file]

> Questo file e la fonte di verita per l'AI. Compilalo rispondendo alle domande sotto. Una volta compilato, l'AI usera queste informazioni in ogni sessione di lavoro.

## [Sezione 1]

**[Domanda guida specifica]**

[Spazio per la risposta dell'utente]

## [Sezione 2]

**[Domanda guida specifica]**

[Spazio per la risposta dell'utente]

[...]
```

### Versione .docx (per l'utente)

Crea una versione .docx dello stesso file usando `npm install -g docx` e il modulo Node.js `docx`. La versione .docx deve essere:
- Formattata con heading chiari, spaziatura leggibile
- Font: Arial
- Stessa struttura del .md ma senza frontmatter YAML
- Intestazione con il nome del file e la data
- Ogni sezione con la domanda guida in grassetto seguita da spazio per la risposta
- In fondo: nota che dice "Dopo aver compilato questo file, aggiorna anche la versione .md nella stessa cartella. La versione .md e quella che l'AI legge e usa."

### Domande guida per ogni file di contesto per archetipo

**Creator — brand_voice:**
- Come descriveresti il tuo tono di voce in 3 aggettivi?
- Che registro usi? (formale, informale, tecnico, colloquiale)
- C'e un modo di parlare che vuoi evitare?
- Scrivi una frase tipica che diresti al tuo pubblico.

**Creator — target_audience:**
- Chi e la persona che ti segue? (eta, ruolo, situazione)
- Qual e il problema principale che ha?
- Cosa desidera ottenere?
- Cosa ha gia provato che non ha funzionato?
- Dove ti trova? (LinkedIn, newsletter, YouTube, ecc.)

**Creator — offer:**
- Cosa offri? (prodotti, servizi, contenuti a pagamento)
- A chi e destinato?
- Quanto costa?
- Perche qualcuno dovrebbe scegliere te rispetto ad alternative?

**Consulente — positioning:**
- Cosa fai esattamente?
- Per chi lo fai? (tipo di azienda/persona)
- Qual e il risultato concreto che ottengono i tuoi clienti?
- Cosa ti differenzia dagli altri che fanno la stessa cosa?

**Consulente — services:**
- Quali servizi offri?
- Come sono strutturati? (pacchetti, ore, progetto, retainer)
- Qual e la fascia di prezzo?
- Qual e il tuo servizio piu richiesto?

**Consulente — case_studies:**
- Descrivi 2-3 risultati ottenuti con clienti
- Per ogni caso: chi era il cliente, qual era il problema, cosa hai fatto, che risultato ha ottenuto

**Founder — positioning:**
- Cosa fa la tua azienda in una frase?
- Per chi lo fa?
- Qual e il problema che risolve?
- Cosa ti differenzia dalla concorrenza?

**Founder — icp:**
- Chi e il tuo cliente ideale? (demografia, ruolo, settore)
- Qual e la sua situazione attuale?
- Qual e il suo problema principale?
- Cosa desidera?
- Cosa ha gia provato?

**Founder — offer_stack:**
- Quali prodotti/servizi vendi?
- Come sono organizzati? (entry-level, core, premium)
- Fasce di prezzo per ognuno?
- Qual e il prodotto/servizio che genera piu ricavo?

**Collaboratore — role_and_goals:**
- Qual e il tuo ruolo esatto?
- Quali sono le tue responsabilita principali?
- Quali sono i tuoi obiettivi per il prossimo quarter?
- Come viene misurato il tuo lavoro?

**Collaboratore — team_context:**
- Chi fa parte del tuo team?
- Chi e il tuo manager/referente?
- Con quali altri team/persone collabori regolarmente?
- Ci sono stakeholder chiave da tenere allineati?

---

## SYSTEM_MAP.md

Genera la SYSTEM_MAP con:

1. **Tabella struttura completa**: numero, nome cartella, tier, frequenza aggiornamento, scopo in una frase
2. **Spiegazione dei tier**: Foundation, Execution, Reference — cosa significano
3. **Tabella di routing dettagliata**: per OGNI tipo di output che l'utente potrebbe creare (basata sulle risposte dell'intervista), indica la cartella di destinazione esatta
4. **Regole di disambiguazione**: per i casi ambigui tipici dell'archetipo (es. "contenuto ricorrente vs. progetto", "idea vs. progetto", "deliverable per cliente vs. template")
5. **Anti-pattern globali**: "Mai creare file nella root", "Mai duplicare file in due cartelle", "Mai lasciare un progetto senza deadline"

La tabella di routing deve avere ALMENO 10-15 righe con i tipi di output specifici per quell'archetipo. Non 5 righe generiche.

---

## LEGGIMI.docx

Questo e il documento piu importante per l'utente. Deve essere:
- Creato come .docx con `npm install -g docx` e il modulo Node.js `docx`
- Formattato in modo professionale e leggibile
- Font: Arial, dimensioni leggibili (titoli 16-18pt, corpo 11-12pt)
- Lunghezza: 3-4 pagine
- Tono: diretto, concreto, amichevole ma non infantile
- Lingua: la stessa dell'utente

### Struttura del LEGGIMI.docx

**COPERTINA / TITOLO**
- Titolo: "Il tuo spazio Cowork — Guida completa"
- Sottotitolo: "Setup personalizzato per [archetipo]"
- Data di creazione

**SEZIONE 1: Come funziona il sistema (max 300 parole)**
- Il concetto dei tier: Foundation (chi sei), Execution (cosa fai), Reference (risorse), Archive (storico)
- Perche questo ordine conta: le cose che cambiano poco stanno in alto, le cose che cambiano spesso stanno al centro
- I README dentro ogni cartella sono istruzioni per l'AI, non documentazione per te. Non devi leggerli tutti, ma non cancellarli. Sono loro che fanno funzionare il sistema.
- Il SYSTEM_MAP alla root e l'indice maestro: prima di iniziare qualsiasi task, l'AI lo legge e sa dove mettere ogni cosa

**SEZIONE 2: La tua struttura cartelle**
- Elenco di ogni cartella creata con spiegazione di 1-2 righe di cosa ci va
- Per ogni cartella: un esempio concreto di cosa ci metteresti (personalizzato sulle risposte dell'intervista)

**SEZIONE 3: I tuoi primi 3 step**
1. Compila i file di contesto in [cartella foundation] — sono la cosa piu importante. Aprili, rispondi alle domande, salvali. Da quel momento l'AI ti conosce.
2. Apri il tuo primo progetto: copia la cartella _TEMPLATE in [cartella progetti], rinominala, compila il README dentro.
3. Prova a chiedere all'AI di fare uno dei task che hai menzionato ([riferimento alla risposta della domanda 4]). Vedrai che sa gia dove mettere l'output.

**SEZIONE 4: Le 5 regole d'oro**
1. Ogni cosa ha un posto. Se non sai dove metterla, chiedi all'AI di consultare il SYSTEM_MAP.
2. Non creare mai file nella cartella principale (root). Scegli sempre una sottocartella.
3. Archivia ogni trimestre. Sposta le cose chiuse in 99_ARCHIVE/[quarter]. Un sistema disordinato smette di funzionare.
4. Tieni aggiornati i file di contesto in [foundation]. Sono la memoria permanente del sistema. Se cambiano, aggiornali.
5. I file .md e .docx nella cartella Foundation devono restare sincronizzati. Se aggiorni uno, aggiorna anche l'altro.

**SEZIONE 5: Come l'AI usa questo sistema**
- Quando inizi una sessione, l'AI legge il SYSTEM_MAP e i README per capire dove vive ogni cosa
- I file di contesto in [foundation] sono il "cervello" del sistema: l'AI li legge per sapere chi sei, cosa fai, per chi
- Non devi dare istruzioni su dove salvare i file: l'AI segue le regole di routing del SYSTEM_MAP
- Se l'AI sbaglia cartella, digli di rileggere il SYSTEM_MAP — imparera

**SEZIONE 6: Come modificare il sistema**
- Vuoi aggiungere una cartella? Creala con un README che segue lo stesso formato delle altre. Aggiorna il SYSTEM_MAP.
- Vuoi eliminare una cartella? Spostala prima in 99_ARCHIVE, non cancellarla.
- Vuoi cambiare il nome di una cartella? Aggiorna il SYSTEM_MAP.
- Il sistema e tuo. Non e rigido. Pero ogni modifica va riflessa nel SYSTEM_MAP, altrimenti l'AI si perde.

---

## PROJECT TEMPLATE README

Il README dentro _TEMPLATE/ di ogni archetipo:

```markdown
---
title: [Nome Progetto]
status: da_compilare
owner: [chi]
start_date: YYYY-MM-DD
deadline: YYYY-MM-DD
---

# [Nome Progetto]

## Obiettivo (in 1 frase)

[Descrivi cosa vuoi ottenere]

## Output misurabile

Il progetto e chiuso quando:
- [criterio concreto]

## In scope / Non in scope

**Fa parte di questo progetto:**
- [cosa si]

**NON fa parte:**
- [cosa no]

## Tasks

- [ ] [task 1]
- [ ] [task 2]
- [ ] [task 3]

## Note e decisioni

[Appunti importanti presi durante il progetto]

## Retrospettiva (compilare a chiusura)

- Cosa e andato bene:
- Cosa non e andato:
- Cosa porto nel prossimo progetto:
```

---

## STEP 4 — MESSAGGIO FINALE

Dopo aver creato TUTTO (cartelle, README, file contesto, SYSTEM_MAP, LEGGIMI.docx), mostra:

> Setup completato! Ecco cosa ho creato:
>
> [N] cartelle principali con [N] sottocartelle
> [N] README operativi — ognuno contiene istruzioni specifiche per l'AI
> [N] file di contesto in dual-format (.md + .docx) in [cartella foundation]
> SYSTEM_MAP.md — l'indice maestro alla root
> LEGGIMI.docx — la guida completa per iniziare
>
> **Adattamenti personalizzati applicati:**
> [Elenco delle personalizzazioni fatte in base alle risposte]
>
> **I tuoi primi 3 step:**
> 1. Apri LEGGIMI.docx e leggilo — ci vogliono 5 minuti
> 2. Compila i file di contesto in [cartella foundation] — sono la cosa piu importante
> 3. Copia il template progetto e apri il tuo primo progetto attivo
>
> Da oggi, ogni volta che inizi un task, l'AI legge il SYSTEM_MAP e sa dove mettere tutto.

---

## NOTE IMPLEMENTATIVE

**La skill DEVE:**
- Rilevare la lingua dell'utente e operare interamente in quella lingua
- Creare tutti i README gia popolati con contenuto reale e specifico, mai placeholder
- Adattare i nomi delle cartelle al contesto dichiarato dall'utente (es. "linkedin/", non "canale_1/")
- Generare la tabella di routing in SYSTEM_MAP.md con i nomi reali delle cartelle create e almeno 10-15 righe specifiche
- Personalizzare LEGGIMI.docx con i nomi reali delle cartelle e riferimenti alle risposte dell'utente
- Creare i file di contesto Foundation in dual-format (.md con frontmatter + .docx formattato)
- Creare il LEGGIMI.docx usando `npm install -g docx` e il modulo Node.js `docx` (vedi istruzioni docx nella sezione LEGGIMI)
- Creare i file .docx di contesto Foundation usando lo stesso approccio
- Elencare esplicitamente nel messaggio finale tutte le personalizzazioni applicate

**Note tecniche per la creazione del LEGGIMI.docx e dei file .docx:**
- Usare `npm install docx` (nella directory di lavoro, non global) e poi il modulo Node.js `docx`
- Usare reference di numbering SEPARATE per ogni lista numerata nel documento (altrimenti la numerazione continua tra liste diverse)
- Usare accenti corretti nella lingua dell'utente (e con accento grave, piu con accento grave, ecc.)
- Validare il .docx dopo la creazione con `python scripts/office/validate.py`

**La skill NON DEVE:**
- Creare strutture con placeholder generici come "[cartella_1]" o "[nome_cliente]"
- Fare piu di 4 domande prima di procedere
- Chiedere conferma piu di una volta (solo allo Step 2)
- Creare README vuoti o con contenuto generico
- Mettere file nella root oltre a SYSTEM_MAP.md e LEGGIMI.docx
- Creare strutture troppo profonde (max 3 livelli di nesting)

**Gestione variabile team:**
- Solo → struttura standard dell'archetipo
- Team piccolo (2-5) → aggiungi sottocartella `team/` nella cartella Operations/più appropriata con note per ruolo
- Team strutturato (6+) → aggiungi cartella dedicata `TEAM/` con: ruoli, procedure, comunicazioni

**Gestione "Altro" (opzione E):**
- Se la descrizione dell'utente somiglia a un archetipo → usa quello come base e adatta
- Se e veramente unico → costruisci una struttura custom seguendo i principi architetturali (tier system, README operativi, SYSTEM_MAP, file cont